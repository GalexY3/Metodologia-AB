# De la predicción individual a la dinámica colectiva

## Pregunta y antecedente directo

Una regla de decisión ajustada a acciones humanas puede servir para predecir la siguiente acción y, sin embargo, generar una trayectoria colectiva diferente al actuar como política de agentes. La diferencia es relevante para la sociología computacional: la adecuación de una explicación de comportamiento individual no basta para establecer que produzca el proceso colectivo observado.

Los datos del dilema del prisionero de Jia permiten una primera prueba de esa diferencia. Se recuperaron del repositorio original el análisis en R, la simulación en C++, una función teórica de MATLAB y la implementación de la plataforma experimental. El código de simulación ya distingue respuestas al vecino en los participantes libres y al contexto en los restringidos. Por tanto, atribuir a nuestros modelos el descubrimiento de reciprocidad dirigida sería incorrecto.

Se utilizó una variante refitada del mecanismo publicado como comparador de dos parámetros. No se ejecutó toda la simulación original ni se afirma haber reproducido su análisis completo. También se reconstruyeron las 735 frecuencias individuales de cooperación del CSV de los autores a partir de los datos originales: coinciden exactamente. Esta comprobación vincula el archivo de datos con una salida publicada y evita iniciar el modelado desde una fuente mal interpretada.

## Diseño de comparación predictiva

Se seleccionaron las personas con libertad para diferenciar acciones de los tratamientos con 25, 50, 75 y 100 % de participantes libres. La respuesta es la cooperación dirigida a un vecino en las rondas 2–50. La primera ronda aporta historia inicial y no se utiliza como respuesta sin antecedentes.

La sesión 1 se empleó para ajustar candidatos, la sesión 2 para seleccionar penalización y la sesión 3 para evaluar. Después de elegir la penalización se reajustaron los modelos con las sesiones 1 y 2. No se usaron identificadores de personas como predictores ni se aprendieron normalizadores en prueba. Las estadísticas agregadas de las sesiones de evaluación ya se habían inspeccionado en la auditoría: se trata de evaluación separada del ajuste, pero no de una muestra confirmatoria nunca observada.

Se compararon cuatro modelos logísticos regularizados. El primero usa únicamente la acción previa del vecino dirigido, siguiendo la estructura del mecanismo publicado. El segundo añade tiempo, tratamiento, dirección, hábito acumulado de cooperación, acción propia previa, pago previo y recuentos del comportamiento vecinal, pero mantiene anónima la identidad de los vecinos que cooperaron. El tercero incorpora a ese contexto la respuesta previa del vecino concreto y sus interacciones. El cuarto representa flexiblemente la combinación de acción propia, respuesta de ese vecino y número de otros vecinos cooperadores.

El rival contextual flexible es necesario para limitar la interpretación de una mejora del tercer modelo. Vencer a un modelo que ignora deliberadamente información diádica no demuestra por sí solo una superioridad ante alternativas competentes que sí pueden usarla.

La penalización se eligió entre 0,1, 1 y 10 mediante pérdida logarítmica de validación. Los tres modelos ampliados seleccionaron el extremo superior del intervalo. No se amplió la búsqueda después de mirar la evaluación; la sensibilidad a penalizaciones mayores permanece sin probar. La selección pondera acciones; el resultado principal promedia las cuatro pérdidas de red con pesos iguales. Esa diferencia entre criterios se conserva explícita.

## Resultados fuera del ajuste

| Modelo | Coeficientes | Pérdida logarítmica media por red | Brier medio |
|---|---:|---:|---:|
| Respuesta al vecino refitada | 2 | 0,4491 | 0,1379 |
| Contexto vecinal anónimo | 26 | 0,3530 | 0,1091 |
| Memoria dirigida y contexto | 29 | 0,3013 | 0,0907 |
| Contexto conjunto flexible | 41 | 0,2988 | 0,0896 |

Ambas medidas penalizan errores probabilísticos; valores menores indican mejor predicción. La incorporación de memoria dirigida mejora la pérdida frente al contexto anónimo en las cuatro redes de evaluación. La mejora media es 0,0517. El modelo conjunto mejora solo 0,0025 en promedio respecto al dirigido y esa diferencia cambia de signo entre redes. No se realizó una prueba de equivalencia ni se presenta una selección confirmatoria de modelo ganador.

Estos resultados muestran capacidad predictiva de la información diádica, condicionada a las familias utilizadas. No identifican reciprocidad causal: la respuesta dirigida puede reflejar reacción a la experiencia, heterogeneidad persistente, expectativas o factores compartidos. Tampoco prueban que las personas apliquen una actualización de aprendizaje por refuerzo concreta.

## Cerrar la dinámica

La segunda prueba deja que los modelos generen sus propias historias. Se utilizó la red de la sesión 3 compuesta enteramente por participantes libres, evitando añadir una política de personas restringidas que no se había ajustado. Los cuatro modelos conservaron sus parámetros. Cada simulación comenzó con las acciones humanas observadas en la primera ronda y luego generó las rondas 2–50 sin recibir nuevas acciones humanas.

Se simularon 256 poblaciones por modelo con los mismos números uniformes para reducir ruido en la comparación. Se recalcularon acciones recibidas, pagos e historial acumulado a partir de cada población simulada. La independencia condicional de acciones contemporáneas por enlace es un supuesto generador adicional. Las 256 réplicas miden variación interna del simulador; no sustituyen a 256 redes humanas. La comparación empírica de esta prueba dispone de una sola red.

| Modelo | Error absoluto medio de trayectoria, en puntos de cooperación |
|---|---:|
| Respuesta al vecino refitada | 30,34 |
| Contexto vecinal anónimo | 5,05 |
| Memoria dirigida y contexto | 7,46 |
| Contexto conjunto flexible | 6,21 |

La clasificación de modelos cambia. El contexto anónimo, que tenía mayor pérdida a un paso que los modelos dirigidos, reproduce mejor esta trayectoria colectiva. Los modelos dirigidos siguen siendo mucho mejores que el comparador de dos parámetros, pero su ventaja de predicción individual no se traslada automáticamente al error colectivo.

La simulación del comparador restringido admite una comprobación analítica. Con probabilidades refitadas de cooperación de 0,2277 después de defección del vecino y de 0,8449 después de cooperación, la media satisface una recursión lineal y converge hacia 0,5948. La trayectoria Monte Carlo se aparta como máximo 0,0042 de la solución exacta. Su gran discrepancia frente a la trayectoria humana no proviene del ruido de muestreo de las simulaciones.

## Alcance de la evidencia

La inversión de clasificación es un resultado exploratorio en una red y un protocolo concretos. No prueba que los modelos más precisos generen siempre peores dinámicas ni identifica cuál de los supuestos causa aquí la diferencia. Puede intervenir la acumulación de errores, la heterogeneidad no modelada, la dependencia entre decisiones simultáneas o una especificación incompleta del historial.

La siguiente comprobación necesaria es repetir la evaluación cerrada dejando fuera las otras redes completas y seleccionando hiperparámetros sin acceso a su prueba. Después cabe enfrentar hipótesis sobre el origen de la discrepancia. Elegir retrospectivamente un nuevo mecanismo a partir de esta inversión no constituiría confirmación independiente de ese mecanismo.

El capítulo aporta una comparación predictiva y generativa reproducible con datos humanos. Su utilidad actual es metodológica y sustantiva para delimitar qué significa validar un agente social. La originalidad científica frente a los antecedentes sigue sin establecerse y no se acredita un hallazgo 2/3 AB.
