# Incentivos privados y formación de una división funcional del trabajo

**Borrador de capítulo empírico-computacional, 15/11/2026.** Material para integrar en el TFM; no manuscrito final ni reivindicación de descubrimiento. Los resultados numéricos definitivos se citan desde los JSON de cada experimento y sus informes, preservando resultados negativos.

## Pregunta y distinciones analíticas

La pregunta de este capítulo es bajo qué condiciones agentes que aprenden a maximizar su beneficio privado llegan a cubrir funciones productivas complementarias cuando una de ellas impone una carga individual adicional. El explanandum es la formación de cobertura funcional desde una situación incompleta. Se distingue de la estabilidad de un equipo ya formado, de la frecuencia de intercambio y de la emergencia de instituciones que regulen ese intercambio. Esas distinciones evitan tratar un indicador agregado de cooperación como prueba suficiente de organización.

La población computacional se organiza en grupos de cuatro integrantes. Cada integrante puede desempeñar una de cuatro profesiones. La producción depende de los tipos de bienes distintos accesibles y de la completitud de la cesta. Una desutilidad privada penaliza el cuarto oficio. La complementariedad tecnológica y la carga desigual se introducen como supuestos del modelo. Por ello, el mero perjuicio de no cubrir esa función no puede contarse como descubrimiento: es una consecuencia de la tecnología estipulada. La pregunta informativa se refiere a las trayectorias de decisión y aprendizaje que generan o evitan esa ausencia.

## Modelo y estimandos

Con intercambios obligatorios, el pago medio de una fase para el individuo i se expresa como

`r_i = .08 + (11/60)d_i + .25·1[d_i=3] − .5·1[rol_i=3] + beta·(1[rol_i=3] − n_3/4) − (.015/8)·1[cambio_i]`.

Aquí d_i cuenta tipos vecinales distintos del propio y n_3 cuenta integrantes del oficio crítico. Las transferencias suman cero dentro de cada grupo y fase. El parámetro beta altera la distribución individual del pago sin modificar directamente su promedio grupal para una configuración fija. Un cambio posterior del promedio observado puede provenir de conductas distintas.

El estimando principal de los factoriales es la diferencia emparejada entre medias de completitud terminal desde inicio monolítico, promediando primero los ambientes de evaluación de cada semilla de entrenamiento. La unidad de réplica es el entrenamiento completo. Los agentes, cliques y fases contribuyen a estimar cada realización, pero no se tratan como réplicas estadísticas independientes del algoritmo entrenado. Los experimentos V131 y V132 usan cuatro semillas nuevas cada uno, doce ambientes nuevos por semilla y endpoint preestablecido de 800 actualizaciones.

La completitud se complementa con el pago privado medio, la frecuencia de cambio y la proporción del oficio crítico. Maximizar completitud no equivale necesariamente a maximizar bienestar: cambiar con demasiada frecuencia o coordinar mal los cambios puede destruir una cobertura ya existente.

## De estabilidad a accesibilidad

Las enumeraciones exactas anteriores muestran que un equipo completo puede ser estable y, a la vez, inaccesible desde estados incompletos bajo una regla de mejor respuesta simultánea. La implementación independiente V129 confirmó la separación en los parámetros de referencia. La activación independiente con probabilidad .5 rompe ese bloqueo y produce 91,4528% de completitud a seis revisiones desde inicio monolítico. Este resultado depende de conocimiento oracular de los pagos y no establece que individuos aprendan por sí mismos la profesión adecuada.

La referencia a [Ramazi et al. (2016)](https://www.pnas.org/doi/full/10.1073/pnas.1610244113) debe acotar el marco: su formulación binaria y sus resultados sobre actualización parcial no constituyen un teorema automático sobre cuatro profesiones complementarias. La enumeración aporta una caracterización del juego utilizado; la importancia general del calendario tiene antecedentes.

## Un resultado negativo que reorienta la explicación

V125 sugirió que añadir observaciones locales podía producir un peor resultado que aprender una activación constante. V127 elevó el rendimiento al alterar el canal de recompensa en una red congelada. Sin embargo, V128, que eliminó ese canal durante todo el entrenamiento, elevó completitud monolítica solo de 24,56% a 29,16%, muy por debajo de los veinte puntos fijados como mejora relevante.

V129 demostró además que, con los parámetros fijos y las donaciones obligatorias, esa recompensa observada es calculable a partir de profesión, frecuencias vecinales, último cambio y fase. La intervención altera una codificación redundante. La red podría aprovechar esa codificación sin aprender a reconstruirla; eso no convierte el canal en información adicional sobre el entorno. Tampoco es válido interpretar una manipulación de política congelada como una manipulación de toda su historia de aprendizaje. El resultado negativo obliga a reducir la prioridad de la explicación informacional fuerte.

## Incentivo privado de cubrir una función ausente

V130 reduce la última decisión del estado `(0,0,1,2)` a dos agentes potencialmente capaces de ocupar la función ausente. Con beta=.125, el beneficio de cambiar si el otro espera es pequeño, mientras cambiar a la vez que el otro es muy perjudicial. El equilibrio simétrico de activación es 121/4160, aproximadamente 2,91%. La descripción no equivale a un equilibrio del episodio completo y también existen soluciones asimétricas donde cambia una sola persona.

El caso revela un conflicto entre cubrir una necesidad colectiva y evitar soportar la carga cuando otro podría asumirla. El [dilema del voluntario de Diekmann (1985)](https://journals.sagepub.com/doi/10.1177/0022002785029004003) aporta un antecedente conceptual. El juego aquí incluye destrucción de cobertura cuando dos personas cambian, de modo que no se equipara su matriz de pagos a la del modelo clásico.

## Intervención en los incentivos y aprendizaje sin oracle

V131 comparó objetivo privado frente a promedio colectivo y compensación baja frente a alta. La elección de profesión seguía siendo oracular, pero el momento de activación se aprendía. La compensación elevó la completitud privada de 34,78% a 91,57%. Los objetivos colectivos dieron alrededor de 91,5% en ambas compensaciones. El control exhaustivo confirmó que la tabla de mejores respuestas era idéntica con ambos valores de beta. El cambio de pagos, y no un cambio de opciones ofrecidas por el oracle, pudo modificar la trayectoria aprendida.

V132 retira esa dependencia: una política categórica elige directamente profesión en cada fase. Conservar la propia profesión representa retención endógena. El actor recibe información propia y vecinal, sin etiquetas de profesión óptima, sin enmascaramiento de acciones y sin consultar la tabla de mejores respuestas. La tabla histórica se vuelve inaccesible en una prueba de instrumentación y el rollout permanece idéntico. Los resultados de las 16 ejecuciones y sus incertidumbres se presentan en `results/INFORME_V132_20261115.md`; los contrastes internos V132 son los pertinentes para atribuir diferencias a beta u objetivo.

V131 y V132 difieren en espacio de acción, parametrización y semillas. Una diferencia entre campañas no identifica por sí sola el efecto causal de retirar el oracle. La demostración técnica relevante de V132 es la elección ocupacional mediante aprendizaje, condicionada a su arquitectura y presupuesto.

## Del reparto de funciones al intercambio voluntario

V133 retira la obligación de regalar manteniendo congeladas las políticas ocupacionales. Esta intervención separa dos componentes del resultado anterior: qué bienes podrían producirse según la distribución de oficios y qué bienes llegan efectivamente a otros individuos. Bajo las políticas privadas bien compensadas, desde equipos balanceados, la cobertura permanece en100% tanto con donación universal como con ausencia de regalos; el retorno neto medio desciende de aproximadamente .755 a .075. La identidad de cobertura no es una sorpresa sociológica: la política de profesión observa roles, último cambio y tiempo, pero carece de entrada efectiva sobre regalos o resultado material. El contrafactual prueba un límite de la arquitectura y de la métrica.

El motor nuevo de intercambio reproduce la física anterior cuando todos donan y coincide con500fixtures de V115. Una intervención sobre un regalo con origen y destinatario fijados permite medir su consecuencia privada: omitirlo ahorra .04 inmediatamente. Si los demás continúan donando sin responder, ese ahorro no tiene coste privado futuro. Con reciprocidad bilateral impuesta, una omisión temprana puede inducir pérdidas futuras mucho mayores. No se ha descubierto reciprocidad: se ha contrastado que estas reglas producen un incentivo distinto en las trayectorias de profesión aprendidas.

El efecto de la omisión se expresa como retorno acumulado descontado desde la ronda intervenida, no como pago medio por ronda. En equipos balanceados y omisión en t16, la ganancia privada media es+.04 sin respuesta, alrededor de−5.81 con tit-for-tat y−11.26 con grim. Las represalias persistentes contribuyen a esas pérdidas; no equivalen a mecanismos eficientes de restauración. La última ronda permite ganar+.04 con cualquiera de estas reglas, porque no quedan consecuencias futuras dentro del horizonte.

V134 contrasta la representabilidad de reciprocidad con su alcanzabilidad mediante aprendizaje. Las profesiones ya aprendidas permanecen congeladas; un donante con memoria de una ronda aprende cinco probabilidades a partir de retornos privados. Dos inicializaciones preestablecidas comparan propensión inicial de regalar .5 y .9. La propensión alta es una condición inicial conductual favorable, sin regla recíproca preentrenada. El reporte por semilla y el criterio operativo de80% en3/4semillas están en `results/INFORME_V134_20261115.md`. Este diseño secuencial no representa aprendizaje conjunto desde cero ni negociación de obligaciones.

Si una política puede representar reglas recíprocas que hacen rentable cooperar, pero el procedimiento de aprendizaje termina con pocos regalos, no se puede identificar el resultado con falta de capacidad representacional. Tampoco se puede probar imposibilidad de aprender con otro estimador, horizonte o condición inicial. El resultado delimita el procedimiento efectivamente ejecutado. La elección del siguiente experimento debe distinguir esas explicaciones, preservando un rival recíproco competente y la comparación con horizonte conocido.

## Mantenimiento desde priors recíprocos y exactitud del objetivo

V135 enfrenta el mismo aprendiz a tres condiciones iniciales con cinco parámetros cada una: donación plana .99, tit-for-tat con error .01 y win-stay/lose-shift con error .01. Los tres comparten la probabilidad inicial .99 y la respuesta tras cooperación mutua .99. El control plano cae a35,60% de regalos después de400actualizaciones. Los dos priors recíprocos alcanzan99,26% y99,68%, respectivamente, manteniendo cooperación alta en las cuatro semillas de cada brazo. No es emergencia espontánea: las contingencias iniciales de reciprocidad fueron impuestas. El resultado permite distinguir aprender a conservar y ajustar un régimen de aprender a producirlo desde una propensión a regalar sin contingencia.

V136 delimita matemáticamente esa distinción en una díada balanceada, con beneficios y costes derivados de la física. Si el oponente no condiciona su conducta al regalo recibido, el coste privado de dar no se compensa con una respuesta futura en el punto inicial. Los gradientes unilaterales exactos refuerzan la defección en los priors planos y refuerzan componentes cooperativos en los recíprocos. Los otros enlaces, la complementariedad conjunta y la variación de roles se mantienen fuera de ese subproblema; no se atribuye a la reducción capacidad explicativa completa del simulador.

La auditoría también precisa qué actualiza el algoritmo histórico. Descontar el retorno futuro desde cada turno no basta para obtener el gradiente exacto del retorno descontado desde el inicio; falta ponderar la contribución de cada turno por gamma^t exterior. La diferencia está publicada en [Nota y Thomas2020](https://people.cs.umass.edu/~pthomas/papers/Nota2020.pdf). En los cinco puntos deV136, la diferencia relativa de norma del campo es8–13%, con signos iguales. Este control no demuestra igualdad de trayectorias. Se conservan resultados históricos como realizaciones del actualizador documentado, y las nuevas afirmaciones sobre optimización exacta requieren una versión corregida y un contraste propio.

## Alcance sociológico, antecedentes y límites

La relación entre funciones colectivas indispensables y desventaja individual permite formular un problema de acción colectiva con contenido distributivo. El modelo no incluye clases sociales, negociación salarial, poder de veto, movilidad laboral costosa o instituciones humanas observadas. Introducir esos conceptos requeriría variables e intervenciones específicas; no basta cambiar la terminología de las profesiones artificiales.

[Yaman et al., preprint de 2022](https://arxiv.org/html/2208.05568v3), ya combina aprendizaje de roles, sanciones y evolución de normas. Sus sanciones se aplican sin decisión voluntaria individual y sus comparadores alteran preferencias sociales. Es un antecedente directo que limita la novedad del rescate por redistribución. [Haupt et al. (2024)](https://link.springer.com/article/10.1007/s10458-024-09682-5) estudia contratos con propuestas y veto. Un beta fijado externamente no implementa esa gobernanza.

En estas campañas la red física y la compartición de parámetros también son exógenas. Una política compartida puede agregar señales de aprendizaje de distintos individuos; por tanto, beneficio privado en el retorno no equivale a autonomía total del proceso de aprendizaje. Las donaciones obligatorias impiden interpretar la cobertura como prueba de cooperación voluntaria conjunta. La siguiente extensión necesaria consiste en permitir que las decisiones privadas de intercambio y los mecanismos de compromiso también se aprendan, con comparadores fuertes y con costes explícitos.

Los resultados son intervenciones computacionales condicionadas. Ningún dataset humano se usa para confirmar los efectos descritos y no hay todavía validación externa pertinente ni acreditación 2/3 AB. El valor actual para el TFM es una explicación progresivamente mejor identificada del modelo, con errores descartados, un resultado negativo conservado y límites de interpretación explícitos.
