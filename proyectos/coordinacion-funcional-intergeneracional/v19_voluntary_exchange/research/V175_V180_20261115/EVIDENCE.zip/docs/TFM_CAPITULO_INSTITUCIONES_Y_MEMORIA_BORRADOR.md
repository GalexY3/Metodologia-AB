# Cooperación privada, formación de acuerdos y memoria ecológica

Informe científico V169–V174, 15/11/2026. Evidencia de simulación y deducción matemática. Se conserva **CT2=61/100**, juicio ordinal histórico del programa; **2/3 NO ACREDITADO**, N2=N3=0, N1 histórico sin auditar. Seis estudios sustantivos, una auditoría de reejecución V169B y una reparación V171B; no contar la reparación como nueva idea independiente. Autorización autónoma del investigador vigente, sin cuota numérica nueva. Ningún entrenamiento queda abierto al cerrar este informe.

## Resultado y decisión científica

El cuello inicial era distinguir cooperación obtenida por deberes programados de una división funcional que los agentes aprendan a adoptar. V169 funciona, pero un precio fijo competente lo iguala. V170 muestra que se pueden dejar libres los regalos si el compromiso modifica sus incentivos, aunque eso no garantiza descubrir el acuerdo. V171 falsó nuestro primer control curricular y V171B lo reparó visiblemente. V172 aprendió adopción y las cuatro profesiones sin un cargo crítico asignado: alrededor del70% desde monocultivo, con capacidad cercana al100% si el régimen se activa externamente. Sigue siendo adopción de una gramática diseñada.

La rama con más incertidumbre nueva es V173–V174. En un modelo externo reciente de instituciones evolutivas, un observador de la historia del recurso reconstruye la riqueza colectiva por conservación. Dos evoluciones desde cero alcanzaron eficiencia0.7834/0.7932 sin observar riqueza ajena, frente a0.8041/0.8131 con observación directa y0.4039/0.4034 al eliminar la señal sin esa memoria. El filtro está programado; no se ha aprendido el balance ecológico. Se prioriza investigar esa dependencia informacional y su aprendizaje frente a seguir afinando precios y multas.

![Resultados principales](../results/FIG_V169_V174_MAIN.png)

## V169: auditoría, ejecución íntegra y márgenes privados

El script original se ejecutó sin modificar sus instrucciones: siete ramas,64mundos de30grupos,4000episodios. Una referencia escalar independiente comprobó2688perfiles de pago y500casos de física V133; errores máximos2.22e−16 y1.11e−16. Los consentimientos privados se producen por las tres decisiones locales; no hay optimización omnisciente en sus Q. El contrato sí impone la entrega y el cambio al oficio crítico tras firma. Los roles0012 y la elección del candidato duplicado se proporcionan externamente.

| Rama | En aprendizaje | Congelada |
|---|---:|---:|
| Sin contrato | 0.00% | 0.00% |
| Vinculante privado | 96.37% | 100.00% |
| Sin salario | 0.97% | 0.00% |
| Salario sin multa | 0.00% | 0.00% |
| Precio fijo | 96.05% | 100.00% |
| TEAM | 95.78% | 100.00% |
| Oracle | 100.00% | 100.00% |

La diferencia principal vinculante−unilateral fue+96.3708pp, bootstrap emparejado64mundos IC95[96.3344,96.4077]pp, durante aprendizaje con exploración. Frente al precio fijo, solamente+0.3174pp. Con políticas congeladas ambos alcanzan100%; no hay ventaja de cooperación del precio aprendido frente al fijo.

El trabajador obtiene.115+P y cada pagador.88−P/3. Contra desacuerdoAllD=.2, las ganancias conjuntas requieren.085<P<2.04; contraAllGive=.446667, requieren.331667<P<1.30. La segunda referencia no es el desacuerdo real aprendido. V169B guardó todas las Q mediante una única inserción al terminar el bucle y reejecutó exactamente los siete endpoints originales. No es réplica independiente. Su evaluación escalar de ambos candidatos por grupo dio precio condicionado a firmas1.405 (2950de3840ofertas a1.6), retorno crítico1.520 y retorno pagador.411667. Los pagadores conservan margen mínimo de veto+.146667 contra su rechazo unilateral con retención óptima del regalo. En4.79% de oportunidades el proponente aún tiene una desviación rentable entre ofertas: cooperación completa no implica equilibrio exacto del conjunto de políticas.

El controlTEAM obtiene100% de cooperación congelada, pero27.86% de votos de pagadores tienen una desviación privada rentable; no acredita consentimiento privadamente óptimo. El precio aceptado original incluía ceros en mundos sin firmas: para negociación se usa ahora el promedio condicionado a contratos. Los pagos son transferencias abstractas de utilidad de suma cero; no se estudian saldos financieros, deuda o límites de liquidez.

## V170: entregar libremente no equivale a carecer de compromiso

Motor nuevo, sin usar V169 para decisiones ni fórmulas de pago. Dos cohortes de32mundos×16grupos,6000episodios, RNGPhilox independiente por mundo y cintas emparejadas por tratamiento. Cada agente tiene tablas propias y aprende solo su retorno realizado. Se mantiene el estado inicial próximo a completitud. Al firmar se compromete salario condicionado a entrega crítica y una multaD por retener el regalo, distribuida entre los otros tres; ninguna acción de entrega se sobrescribe en las ramas libres. No hay multas sin firma. Paridad contra motor escalar en2000casos, error2.22e−16.

| Entrega y contrato | Cohorte A | Cohorte B |
|---|---:|---:|
| Regalo forzado | 100.00% | 100.00% |
| Solo salario | 0.00% | 0.20% |
| Multa .08 | 2.83% | 3.71% |
| Multa .20 | 57.52% | 54.59% |
| Aprende multa | 78.52% | 78.03% |
| Aprende precio y multa | 98.05% | 97.36% |

Para un pagador firmado, donar−retener=D−.12; para el crítico, D+P−.12. Son identidades impuestas por el mecanismo. Con D=.20, retener deja de ser mejor respuesta, pero solamente54.59–57.52% de grupos llega a cooperar congeladamente. El menú rico alcanza97.36–98.05%, sin demostrar por ello superioridad de negociación. La auditoría posterior detecta que los éxitos ocasionales conD=.08 incluyen regalos estrictamente dominados:75% de decisiones de regalo dentro de sus contratos permiten ganar.04 reteniendo. Las políticas finitas no se declaran racionales perfectas por su tasa de éxito.

## V171 y reparación V171B: competencia fuera del acuerdo

Se ejecutó todo el factorial salario×multa en cohortes nuevasC,D. El contrato fijoP=.8,D=.4 alcanza100% desde cero en ambas: refuta que el menú negociador sea necesario para el rendimiento alto deV170. El currículo inicial impuso contratos durante4500episodios para aprender regalos y luego congeló esa conducta para aprender firmas1500episodios. Eso dejó sin experiencias toda la política de desacuerdo. Todos sus valoresQ fuera del contrato seguían empatados: el selector durante negociación donaba50% y el `argmax` final retenía. No se interpreta ese control incompleto como un fracaso general deMOCA.

| P | D | Scratch C | Scratch D | Currículo incompleto C | Currículo incompleto D |
|---:|---:|---:|---:|---:|---:|
| 0.2 | 0.2 | 55.66% | 56.45% | 36.82% | 35.45% |
| 0.2 | 0.4 | 96.68% | 95.12% | 34.86% | 33.30% |
| 0.4 | 0.2 | 58.20% | 58.79% | 65.04% | 62.40% |
| 0.4 | 0.4 | 100.00% | 100.00% | 66.60% | 64.16% |
| 0.8 | 0.2 | 94.34% | 91.89% | 61.23% | 59.08% |
| 0.8 | 0.4 | 100.00% | 100.00% | 62.79% | 61.23% |
| 1.6 | 0.2 | 21.68% | 16.11% | 8.20% | 8.79% |
| 1.6 | 0.4 | 98.73% | 99.02% | 12.01% | 9.18% |

El discriminante preregistradoDiD>.20 falló: .18359/.17773. Además, el currículo redujo el éxito del contrato bajo; unaDiD positiva por perjudicar más al contrato alto no probaría que ayuda al bajo. Esta limitación del estimando se conserva.

V171B añadió exclusivamente muestreo del subproblema nulo durante el currículo, sin imponer la retención. Nuevas cohortesG,H, mismo presupuesto. Todos los agentes aprendieron a retener fuera del acuerdo, sin empates. ParaP=.2,D=.2 el éxito pasó56.45→93.85% y59.08→93.55%. Ganancias+37.40pp(IC95[33.30,41.21]) y+34.47pp([30.66,38.38]);DiD+.39453/.35449, ahora con ganancias absolutas positivas. El criterio secundario todas las celdas≥95% volvió a fallar; no se borra. El fijoP=.8,D=.4 sigue alcanzando100% desde cero, mientras el currículo obtiene97.95/99.02%. No hay un algoritmo uniformemente superior.

Haupt etal.2024 ya trata negociación voluntaria de transferencias y sesgos de aprendizaje de contratos; nuestra adaptación curricular no es suMOCA original. Aprender subproblemas y mejorar un currículo defectuoso no son novedades reivindicadas.

## V172: profesiones realmente libres, institución aún diseñada

Se retiraron la asignación del candidato crítico y las profesiones0012 preparadas. Cualquier persona seleccionada puede escoger cualquiera de los cuatro oficios, que persisten. Todas eligen su regalo, sin deberes físicos. El contratoP=.8,D=.4 no asigna profesiones: remunera entregas de trabajadores críticos, repartiendo ingreso si hay varios, y multa incumplimientos de entrega. EnPRIVATE_OPT_IN oferta y aceptación son privadas;PRIVATE_ALWAYS_ACTIVE elimina la adopción como control de capacidad, no es emergencia institucional.

Dos cohortes de16mundos×16grupos,16000rondas, tres inicios. Son aprendices contextuales miopes de retorno privado inmediato; no planificación óptima descontada ni parámetros compartidos. La evaluación congela todas las tablas y usa2000rondas con nuevas secuencias de oportunidades, midiendo últimas500. Se comprobaron2000casos de pagos contra referencia escalar y1000contra físicaV133 ajustando coste, errores≤2.22e−16.

| Inicialización | Privado E | Privado F | Siempre activo E | Siempre activo F | Sin contrato E/F |
|---|---:|---:|---:|---:|---:|
| BALANCED | 69.58% | 76.66% | 99.82% | 99.61% | 0% / 0% |
| RANDOM | 73.43% | 71.83% | 99.61% | 99.89% | 0% / 0% |
| MONOLITH | 69.84% | 70.93% | 99.87% | 100.00% | 0% / 0% |

DesdeMONOLITH, el déficit de adopción respecto a activación impuesta fue−30.03pp(IC95[−33.85,−25.54]) y−29.07pp([−33.94,−24.66]). No se cumplen los criterios extremos de≥90% privado ni≤50% privado; el resultado es intermedio y no se fuerza a encajar en ellos. Sí se demuestra capacidad de organizar funciones desde un monocultivo bajo esta gramática, muy por encima de la donación nula sin régimen. La física, tamaño, pertenencia, sanciones y calendario de oportunidades son exógenos. No inferir que se aprendieron constituciones, grupos o normas morales.

## V173: observabilidad por conservación en un antecedente externo

Se localizó una continuación deItao/Kaneko, arXiv2507.22555v2(1/11/2026), que ya estudia monitoreo anónimo, turnos, diversidad, ruido e historia demográfica. Se recuperó su código y ejecutó un piloto originalN100,M5,T1000,3000generaciones:Qfinal medio.783963. No se presenta como réplica estadística de todo el artículo. Un motor independiente coincidió exactamente con `play_generation` original en acciones, recurso yfitness de200grupos×500pasos.

SeaZ_t la riqueza total, a=1−κ=.75 yR el crecimiento conocido. Como toda extracción pasa del recurso a la riqueza de los agentes:

**Z_(t+1)=a Z_t+R(x_t)−x_(t+1).**

El observador actualiza la misma ecuación usando solo memoria de un escalar y recurso actual/pasado. Su error cumple **e_t=a^t e_0**. Con estado inicial conocido reconstruye exactamente en aritmética real; sin calibrar, el error inicial decae. No revela identidades ni riqueza individual ajena. La memoria contiene una señal social inferida, por lo que sería incorrecto decir que no existe información sobre otros: desaparece la medición directa de sus riquezas. La ley de actualización está programada.

Treinta pruebas con acciones arbitrarias,M3–64 y distintos estados iniciales verificaron la identidad con error≤7.22e−16. La transferencia de la población evolutiva a32mundos×16grupos porM dio, paraM5, riqueza observadaQ=.730730, memoria calibrada.730730, memoria nominal.725524 y señal eliminada.500538. M8: .745696/.745696/.745649/.494443;M16:.773615/.773615/.773268/.494776. No son cuatro experimentos humanos ni aprendizaje nuevo enM16. La memoria nominal cambia muchas acciones y fases aunque preserve aproximadamente la eficiencia: reconstrucción asintótica no significa trayectorias idénticas.

Se conserva un fallo numérico: enM3/mundo30 hubo850acciones distintas con memoria calibrada, en estados con recurso≤6.79e−22 y diferencias máximas defitness4.94e−43. No se afirma equivalencia bit a bit universal. No se trata de un fracaso de la identidad en aritmética real; sí limita su implementación finita en políticas discontinuas.

Con un flujo ocultoξ=.001, **e_(t+1)=.75e_t−ξ**, sesgo límite−.004. Se verificó en todos los mundos. Informar el flujo al observador restaura igualdad conFULL en las acciones evaluadas. El flujo oculto a veces mejora la eficiencia: perder equivalencia informativa no implica daño absoluto. No convertir la observación en una ley general de beneficios del ruido, que los antecedentes ya exploran.

![Observabilidad](../results/FIG_V173_OBSERVABILITY.png)

## V174: formación desde cero con memoria ecológica

La transferenciaV173 no prueba que las reglas puedan aparecer sin riqueza ajena. Se ejecutaron seis evoluciones nuevas desde cero, dos semillas×tres condiciones, con el motor original de reproducción sin cambiar. RESOURCE_MEMORY reemplaza solamente la señal colectiva por el observador de un escalar, inicializado en1 sin consultar el promedio realmente sorteado. FULL conserva código intacto yNO_PEER elimina esa señal sin añadir memoria. Cada individuo reproduce según su propiafitness; la selección y reagrupación introducen la estructura evolutiva descrita por los autores, no racionalidad privada óptima ni retornoTEAM en un gradiente.

| Semilla evolutiva | FULL | Memoria del recurso | Sin señal | Memoria−FULL |
|---|---:|---:|---:|---:|
| 174115 | 0.804078 | 0.783433 | 0.403897 | -0.020644 |
| 174116 | 0.813085 | 0.793187 | 0.403387 | -0.019898 |

Ambas semillas cumplen los criterios puntuales preespecificadosQmemoria≥.70 y diferencia respecto aFULL≤.05. No se ha hecho una prueba de equivalencia poblacional conn2. Los coeficientes de decisión evolucionan desde cero; el observador y la dinámica conocida son suministrados. No se ha aprendido a observar ni se ha descubierto la ecuación ecológica. Un comparador con memoria genérica aprendida sigue pendiente. Tampoco se ha establecido robustez de la formación a leyes desconocidas, heterogeneidad de depreciación o flujos abiertos.

## Originalidad, validez y evaluación AB

La contribución candidata precisa es una restricción de identificación: en este sistema conservativo, comparar una política sin memoria con y sinriqueza colectiva no basta para demostrar necesidad informacional de medirla. Una arquitectura que recuerde el recurso dispone de un canal reconstruible, con error y condiciones de ruptura explícitos. Esto aporta una predicción concreta y una prueba en código publicado; aún puede ser una aplicación conocida de observabilidad. El concepto de observador y la cooperación con señales públicas tienen antecedentes clásicos. No declarar nuevo el mecanismo de turnos deItao/Kaneko ni las transferencias/sanciones deHaupt/Yaman.

**2/3 no acreditado**: faltan prioridad específica contrastada de forma más amplia, rivales con memoria aprendida, validación fuera del ecosistema utilizado para formular la hipótesis y confirmación científica independiente. Dos motores y semillas distintas mejoran trazabilidad interna; no se equiparan a un equipo independiente ni a humanos. Se conserva61/100 sin incremento y no se concede un nuevoN1 por acumular ensayos. Las ramas de contratos y ecología quedan separadas(D2); no trasladar entre ellas validez externa.

![CT2](../results/FIG_CT2_V169_V174.png)



Este capítulo de trabajo complementa el manuscrito anterior; requiere integración bibliográfica y revisión académica. Véase el informe completoV169–V174 para fuentes, protocolos y trazabilidad.
