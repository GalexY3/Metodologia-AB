# Qué permiten contrastar los datos humanos

**Borrador de capítulo del TFM, 15 de noviembre de 2026.** Los análisis de este capítulo son exploratorios. Incluyen una reproducción computacional de resultados publicados y una evaluación de adecuación de fuentes; no constituyen una confirmación de las predicciones del simulador.

## Dos formas distintas de autonomía

Para conectar un modelo de agentes con observaciones humanas hace falta identificar qué decisiones pueden tomar los participantes y qué variables registran los datos. La etiqueta general de autonomía no basta para considerar equivalentes dos tratamientos experimentales.

El estudio de [Jia y colaboradores (2025)](https://www.nature.com/articles/s41562-025-02289-0) permite diferenciar acciones hacia vecinos. El bloque del dilema del prisionero contiene quince redes de cuarenta y nueve personas, observadas durante cincuenta rondas. La inspección de todas las relaciones dirigidas confirma que los vecinos permanecen fijos. La agencia estudiada amplía las acciones que una persona puede dirigir a contactos diferentes; no permite sustituir esos contactos. La interpretación inicial del proyecto, que acercaba ese tratamiento a una elección de compañeros, debe corregirse.

El estudio de [Stallen y colaboradores (2023)](https://www.nature.com/articles/s41467-023-42128-2) sí examina un mecanismo de emparejamiento basado en preferencias por tipos de compañero. Esos tipos combinan dotaciones y productividad altas o bajas. No representan oficios complementarios elegidos durante el aprendizaje. Por ello, los estudios no ofrecen efectos opuestos de un mismo tratamiento ni validan automáticamente las profesiones del simulador.

## Estructura de los datos y unidad de inferencia

En Jia, cada condición del dilema del prisionero dispone de tres redes. Hay 36.750 registros de persona y ronda y 147.000 acciones dirigidas. La abundancia de acciones permite estudiar respuestas temporales, pero no convierte cada acción en una réplica independiente del tratamiento de red. Se verificó la correspondencia entre la acción enviada, la recibida por el vecino y el tipo atribuido a ese vecino. También se reconstruyeron los pagos de las cuatro combinaciones de acciones: cooperación mutua, 4; cooperar frente a defección, −2; desertar frente a cooperación, 6; defección mutua, 0.

En Stallen, las 8.064 filas corresponden a 336 personas durante 24 rondas. Las interacciones ocurren dentro de 42 grupos de ocho personas, con 21 grupos por condición. El segundo archivo, que incorpora preferencias e historial, contiene exactamente las 4.032 filas de la condición de elección libre ya presentes en el primero. Sus columnas compartidas coinciden. Tratarlos como muestras diferentes duplicaría la mitad de las observaciones.

Los campos de preferencias y compañero anterior identifican tipos, no personas. Repetir un tipo de compañero no permite, por sí solo, demostrar persistencia de un vínculo entre dos individuos concretos. Los valores ausentes de historial en la primera ronda se consideran no aplicables y no se sustituyen por ceros.

## Reproducción de la desigualdad y precisión del estimando

La reproducción de una cifra requiere preservar su definición. Calcular desigualdad sobre la riqueza bruta acumulada no reproduce el mismo resultado que calcularla sobre las ganancias generadas por encima de las dotaciones recibidas.

Para cada participante se obtuvo la ganancia neta del juego sumando sus ingresos por ronda y restando las dotaciones de las veinticuatro rondas. El Gini de esas ganancias es 0,2443 con compañero asignado y 0,4364 con elección. Se reproducen así los valores publicados redondeados a 0,24 y 0,44. La diferencia es 0,1921. Un remuestreo exploratorio de grupos, estratificado por condición y plataforma de reclutamiento, da un intervalo percentil del 95 % entre 0,1500 y 0,2343.

Esta operación no es una replicación con participantes nuevos. Comprueba que la fuente descargada y la definición reconstruida permiten recuperar resultados de los autores. Un participante de elección libre presenta una ganancia neta de −25 unidades; se conserva ese valor. Aplicar la fórmula del Gini a una distribución con valores negativos exige explicar que sus límites habituales pueden dejar de cumplirse en general.

La contribución proporcional media al bien público fue del 56,62 % con asignación y del 60,92 % con elección. La diferencia descriptiva es de 4,30 puntos porcentuales; su intervalo de remuestreo de grupos, de −3,83 a 12,69 puntos, incluye cero. Esto no refuta los análisis longitudinales publicados, que estiman otros efectos. Impide presentar esta diferencia global concreta como una mejora promedio precisamente estimada.

## Consecuencias para el programa de investigación

Los datos de Jia permiten estudiar reciprocidad dirigida y restricciones a la diferenciación de acciones. Los de Stallen permiten estudiar preferencias por tipos, emparejamiento y distribución de ganancias. Ninguno contiene las decisiones ocupacionales ni los contratos de nuestro modelo. Son posibles fuentes para preguntas próximas, siempre que se formule un estimando que exista realmente en sus variables.

Una continuación defendible debe consultar los modelos y el código originales antes de reivindicar una explicación nueva. Una comparación predictiva sobre acciones futuras puede separar sesiones de desarrollo y prueba, preservando la dependencia dentro de cada red. Su éxito demostraría capacidad predictiva fuera de la muestra de ajuste, no causalidad de una regla de aprendizaje ni validación directa de los agentes.

Los originales permanecen intactos. Los scripts V137 y V138 conservan cálculos, hashes y controles; el informe técnico documenta límites de acceso, licencia y lectura. El trabajo fortalece la base empírica del TFM, pero la originalidad y la confirmación independiente de un mecanismo propio siguen pendientes.
