# Cambio de hipótesis tras el estancamiento CT2 55/100 — V153 a V156

**Fecha:** 15 noviembre 2026. Investigaciones sintéticas auditadas en PC grande mediante GM. **No modificar CT2 ni atribuir 2/3**: no existe evidencia humana externa nueva, novedad teórica contrastada ni sistema de agentes aprendidos que forme instituciones endógenamente. Los resultados son de un juego artificial construido para contrastar funciones complementarias.

## V153. Ocupaciones y asociación

Archivo `results/V153_ENDOGENOUS_OCCUPATIONS_MEMBERSHIP_SEQUENCING.json`; código `v153_joint_occupation_membership.py`; protocolo `PREREG_V153_OCCUPATION_AFFILIATION_SEQUENCE.md`.

En 64 mundos de 120 agentes, todos los tratamientos que permiten mejores respuestas privadas de cambio de profesión terminan con 100% de equipos k4 completos, independientemente de si la afiliación mediante intercambios ocurre antes, después o intercalada. Solo intercambios sin cambio de oficio consiguen 76,875% (d=4) y 83,125% (d=119). **Resultado negativo discriminante:** la economía con oficios cambiables bajo información perfecta hace trivial la optimización de composición y no identifica un mecanismo nuevo de negociación.

## V154. Agentes con información privada

Archivo `results/V154_BLIND_ROLE_LEARNING_SHOCK_COMPARISON.json`; código `v154_blind_role_learning.py`; protocolo `PREREG_V154_BLIND_ROLE_LEARNING.md`.

Con 64 semillas nuevas, 12.000 visitas por población y sin choque, fracción final de equipos completos:
- Mejor respuesta con contrafactuales de los cuatro roles: 100%.
- Ensayo reversible de un rol alternativo, con recompensa individual inmediata propia: 100%.
- Bandit privado independiente (`alpha=.25,epsilon=.15`, valor de cada profesión, exploración persistente): 6,61%.
- Rol aleatorio: 8,39%.
- No cambiar: 8,59%.

El protocolo con choque aleatorio de profesiones del 25% a mitad de trayectoria conserva 100% para oracle y ensayo privado al final; el bandit tiene 6,67%. Esta comparación **no identifica una imposibilidad general de aprendizaje**: el bandit es intencionadamente simple, carece de contexto y utiliza exploración persistente. El ensayo reversible puede obtener una comparación de rendimiento que el bandit no tiene; no igualar cargas informativas. Repetir con rivales contextuales, exploración decreciente y costes de prueba antes de discutir resultados de RL.

## V155. Auditoría exacta de equilibrio de cuatro agentes

Archivo `results/V155_EXACT_OCCUPATIONAL_EQUILIBRIA_AUDIT.json`; código `v155_exact_role_equilibria.py`. Las 256 configuraciones ordenadas con cuatro roles y sus 12 desviaciones individuales por configuración se enumeran exhaustivamente; se calculan estados sin mejoras privadas individuales y componentes fuertemente conectados del grafo de mejoras.

Para transferencia ocupacional de suma cero `beta=0` y coste de cambio `c=.015`, existen **36 estados estables, todos con tres profesiones distintas**. Para `beta=.125,c=.015`, existen **24 estados estables y todos están completos**. La diferencia es una propiedad exacta del juego finito, no el resultado de la selección aleatoria de 64 simulaciones.

## V156. Umbrales e histéresis de la compensación

Archivo `results/V156_ROLE_COMPENSATION_HYSTERESIS.json`; código `v156_role_compensation_hysteresis.py`; protocolo `PREREG_V156_INSTITUTIONAL_HYSTERESIS.md`.

En grupos k4, la retribución material compartida depende del número d de profesiones distintas: `f(4)=.88`, `f(3)=.4466667`. El coste privado del rol crítico 3 es .5. La subvención ocupacional es `beta * [I(rol3)-fraccion_grupal_rol3]`, suma cero. La ventaja de un agente que cambia de rol duplicado al crítico, antes del coste de reasignación, es `-1/15+3beta/4`. La diferencia no es una proposición original sobre la economía real.

El coste individual de reasignación `c=.015` genera dos umbrales distintos, contrastados mediante enumeración exacta:

`beta_down = (4/3)*(1/15-c) = 0.0688889` y `beta_up = (4/3)*(1/15+c) = 0.1088889`.

Para un mismo nivel final `beta=.09` dentro del intervalo coexisten **24 equilibrios completos y 36 incompletos**. El test en 64 mundos, 3000 oportunidades de decisión con beta previo y 3000 con el mismo beta final .09 para todos, revela:

| Historia inicial del incentivo | Estado final beta=.09, c=.015 |
| --- | ---: |
| 0 → .09 (LOW_TO_MID) | 0% de grupos completos |
| .125 → .09 (HIGH_TO_MID) | 100% |
| .09 → .09 (MID_TO_MID) | 55,89% |

El contrafactual mecánico **sin coste de cambio** `c=0` elimina la divergencia: LOW_TO_MID y HIGH_TO_MID terminan ambos en **100%**. Las mismas 64 poblaciones, las mismas oportunidades de actualización y los mismos parámetros finales producen resultados opuestos cuando existe coste de cambio: una demostración *dentro del modelo* de histéresis y selección histórica de equilibrios.

## Significado y límites

La histéresis y los equilibrios múltiples son fenómenos teóricos bien conocidos; las transferencias entre integrantes y la estabilidad de asociaciones tienen literatura en teoría de juegos hedónicos (Bilò, Monaco y Moscardelli, AAAI 2022, DOI 10.1609/aaai.v36i9.21156), y la coordinación con información parcial y no estacionariedad es problema clásico de MARL (véase el survey `10.1007/s10462-021-09996-w`). El modelo propio muestra una **condición física e institucional específica** y permite un contrafactual exacto, pero no autoriza calificarlo de descubrimiento sociológico general.

**Cambio de hipótesis científico:** analizar la creación endógena de instituciones que compensan el oficio costoso. Cuando beta es impuesto por un diseñador, podemos cruzar el umbral; la cuestión difícil es si agentes sin coordinador central pueden negociar, aprender y financiar una transferencia de suma cero suficiente para superar `beta_up` y si después conservan la organización aun cuando la institución se debilita (`beta_down`). Contrastar con mecanismos conocidos de bienes públicos, clubes y formación hedónica de grupos, con generalización a k no entrenados y reglas de inversión/entrada verdaderamente privadas.

**Condición de continuación R5:** no generar más variantes de V153 por sí mismas. El siguiente experimento debe eliminar el beta impuesto o la información perfecta, comparar con un rival competente de acuerdos y probar en una segunda tecnología de producción. Si no funciona, registrar resultado negativo, sin elevar CT2.
