# INFORME DE INVESTIGACIÓN — V157 a V167A
**Fecha:** 15/11/2026. **Naturaleza:** demostraciones exactas y validaciones de simulación artificial. **Estado CT2:** el archivo vivo `results/AB_PROGRESO_CT2_CT3.json` registra **61/100** para proximidad 2/3 (V150–V153 de la rama de pertenencia y comparativa k); esta nueva campaña V157–V167 no modifica la puntuación, ni acredita 2/3, ni un descubrimiento empírico sobre personas. Los identificadores V153/V154 existen también en una línea paralela dentro del mismo directorio, por lo que deben identificarse por NOMBRE DE SCRIPT y SHA256, no únicamente por número de ciclo.

## Planteamiento
El estancamiento de CT2=55/100 había llevado a probar mejoras predictivas y más rondas de modelos sin resolver qué significa una institución emergente. Después de V153–V156 se formulan tres interrogantes más precisos. ¿Cuándo una transferencia compensatoria convierte la división del trabajo en una configuración individualmente aceptable? ¿Puede una sociedad sostener una función que ninguno de sus microestados actuales mantiene como equilibrio? ¿Qué dependencia estructural hay entre tamaño de grupo, fiabilidad de consentimiento y coordinación de las señales de aceptación?

Las reglas materiales del primer sistema son `u_i=f(d)-δ1[r_i=c]+β(1[r_i=c]-n_c/k)`, con compensación cero-suma, k=4, c=profesión costosa, δ=.5, y coste por cambio de profesión `s=.015`. El trabajo y el tamaño de las coaliciones siguen siendo impuestos. El modelo original de V117 suministra el f(d); V158 añade otras tecnologías como pruebas de sensibilidad. La política de mejor respuesta recibe contrafactuales exactos en la mayor parte de la campaña y NO es un sistema MARL que aprende instituciones autónomamente.

## Resultado 1 — Doble histéresis y sobrerrecompensa (V158 y V160)
Sea `B=f(4)-f(3)=13/30≈.433333`, `D=f(2)-f(1)=.55/3`, `δ=.5`, `s=.015`. El juego de cuatro ocupaciones tiene umbrales analíticos sujetos a la estructura especificada

`β_low = 4/3(δ−s−B)=.0688889`,
`β_enter = 4/3(δ+s−B)=.1088889`,
`β_mono = 4/3(D+δ−s)=.8911111`,
`β_over = 4/3(B+δ+s)=1.2644444`.

En `β=.09`, 60 equilibrios estáticos: 24 equipos con cuatro oficios y 36 con tres oficios. En `β=1.0`, 25 equilibrios: 24 con los cuatro oficios y uno con todos los trabajadores en el oficio subvencionado. La segunda biestabilidad es contraria a interpretar cualquier aumento de incentivos como mejora continua.

V160, 64 nuevas poblaciones de 30 equipos: todas con `β_final=1.0` sin shock. Una historia inicial de `β=.3` conserva 100% de equipos completos; una historia de `β=1.6` conserva 0% de equipos completos y 100% de monocultivos críticos. En `β_final=.7` ambas convergen a 100% de equipos completos; con `β_final=1.3` todas convergen a monocultivo. La prueba de choque del 25% de las ocupaciones reduce la separación pero no la suprime: historia previa .3→1.0 termina 78.91% completos, historia previa 1.6→1.0 6.67%. El resultado solo acredita selección histórica de equilibrios EN ESTA física artificial, una familia de fenómenos previamente conocida en sistemas no lineales y teoría de juegos.

## Resultado 2 — Contratos localmente aprobados que rescatan una función social costosa (V159 y V161)
En V159 los oficios y contratos pueden ser elegidos localmente pero el protocolo de negociación y cumplimiento es diseñado por el investigador. Tras una fase sin compensación que acaba con 0% de grupos completos, una oferta privada del candidato crítico `P=max(δ+s−B,0)+m` se reparte en tres pagos iguales de los restantes integrantes, quienes pueden aceptar únicamente si su incremento particular es positivo. Para el margen pequeño `m=.01`, la firma hace posible 100% de equipos completos al final, comparado con 0% sin contrato, 0% con votación separada estricta y 100% con subsidio obligatorio β=.125. Una extracción excesiva (m=1.30) es rechazada universalmente y deja 0% de grupos completos. Con q=.35 de señal independiente para cada donante, 87.865% llegan a completitud tras 3000 oportunidades; con contratos revocables, 75% parecen completos en el corte terminal.

V161 compara cuatro tecnologías sobre 64 nuevas poblaciones, REUSANDO el mismo motor de V159. B=.2,δ=.5: subsidio fijo β=.125 alcanza 0%, el contrato por acuerdo local alcanza 100%. B=.2,δ=.8: ningún mecanismo logra completitud, coherente con que la mejora total `kB−δ−s<0`, de modo que repartir beneficios no puede crear excedente material. B=.4333,δ=.8: fijo β=.125 falla, el contrato local 100%; B=.65,δ=.5: todos 100% aun sin contrato. Criterio exacto de viabilidad estricta del acuerdo (cuando puede formarse un equipo completo a partir de los k−1 tipos) `δ+s+m<kB`, sujeto a los pagos y derechos descritos.

Las contribuciones materiales son obligatorias, las coaliciones tienen tamaño k fijado por diseño, el trabajador percibe recompensa después de firmar y existen contrafactuales conocidos para los votos. No se ha demostrado ni creación espontánea del derecho de contrato, ni aprendizaje de negociación ni regulación políticamente legitimada.

## Resultado 3 — Sociedad funcional sin equilibrio microindividual (V162 y V163)
La auditoría V162 reproduce exactamente la cohorte V159, congela el estado final e inspecciona *todas* las alternativas de cambio profesional y la revocación unilateral del pago. La política revocable tiene 75% de equipos completos en el último corte, pero **0% de equipos simultáneamente completos y localmente estables**. Los donantes tienen incentivo inmediato para dejar de pagar; el trabajador crítico queda con incentivo a abandonar cuando ya no cobra. Los equipos con contrato vinculante y compensación exógena sí alcanzan 100% completos y estables.

V163 repite con 64 nuevas poblaciones y 12000 oportunidades institucionales, observación de cada instante:
- Revocabilidad: **72.5015%** de ocupación funcional a lo largo del tiempo, 72.65% en una ventana temprana y 72.56% en la última ventana; **0%** de completitud Nash local al final.
- Solo **5.50565 de los 30 grupos** conservan un contrato activo por término medio; **54.149%** de grupos están completos sin contrato vigente.
- **104429 episodios completados** de continuidad funcional, duración media **158.209 eventos de selección global**, aunque estos episodios NO son unidades independientes.
- Contratos vinculantes 100% completos de manera persistente; contratos vinculantes con canal imperfecto q=.35 llegan a casi 100% al final de 12000 contactos, porque una sola firma puede hacer de la completitud un estado absorbente.

[Interpretación limitada] Esto permite distinguir tres conceptos: integridad funcional instantánea, disponibilidad temporal de una función social y equilibrio privado de los individuos. El tercer concepto NO es condición necesaria para el segundo cuando la temporalidad asincrónica permite relevo de contratos y ocupaciones. Es una ilustración diseñada de la distinción entre homeostasis macroscópica y estabilidad microscópica, no demostración original de cibernética ni verificación del Modelo de Sistema Viable de Beer.

## Resultado 4 — Mecanismo micro-macro exacto y generalización a k (V164)
En la nueva tecnología, el grupo k tiene oficios 0..k−1, con uno costoso, `B=.40`, `δ=.50`, `s=.015`, precio negociado localmente `P=.125`. En el motor microindividual independiente V164, **sin usar estados Markov para decidir las acciones**, la condición de contrato revocable y especialización produce exclusivamente tres clases:
I — Grupo incompleto sin crítico, con dos trabajadores capaces de solicitar el puesto.
B — Grupo con todas las funciones y contrato válido, revocable por los k−1 donantes.
U — Grupo con todas las funciones pero contrato ya revocado; el crítico abandonará cuando le toque decidir.

Con selección uniforme de una persona de N=30k en cada evento, las intensidades por oportunidad son `I→B:2/N`, `B→U:(k−1)/N`, `U→I:1/N`. Se deduce mediante conservación de flujo la distribución estacionaria

`π_I=(k−1)/(3k−1)`; `π_B=2/(3k−1)`; `π_U=2(k−1)/(3k−1)`.

La probabilidad de equipo funcional es `F(k,1)=2k/(3k−1)`. Para k=4 predice 72.727%, cerca del 72.50% de V163, donde los parámetros materiales y el motor eran diferentes. V164 utiliza 64 nuevas poblaciones por tamaño y 30000 decisiones por población, descartando las primeras 6000. La siguiente tabla está respaldada por su JSON de resultados:

| k | Teoría F(k,1) | Simulación |
|---|---:|---:|
| 2 | 80.000% | 79.995% |
| 3 | 75.000% | 75.012% |
| 4 | 72.727% | 72.758% |
| 5 | 71.429% | 71.426% |
| 6 | 70.588% | 70.620% |
| 8 | 69.565% | 69.537% |

Los seis valores exactos quedan dentro del intervalo descriptivo bootstrap95 calculado sobre 64 mundos en cada k. La duración de un episodio funcional se predice como `N/(k−1)+N` **eventos de selección de una persona entre todas las poblaciones**, no como duración de reloj; el aumento con k se debe parcialmente al escalado N=30k. Este caso finito ha pasado una prueba entre motores diferentes de su microdinámica, pero ambas tecnologías están diseñadas para preservar la misma estructura de tres estados.

## Resultado 5 — Unanimidad, confiabilidad y límite de tamaño (V165, V165B)
Si se exigen k−1 votos y cada voto llega favorablemente con probabilidad q INDEPENDIENTE, la transición I→B tiene intensidad `2q^(k−1)/N`, mientras B→U y U→I mantienen sus intensidades. La fracción funcional exacta es

`F(k,q)=[1+1/(k−1)] / [1/(2q^(k−1))+1+1/(k−1)]`.

Para todo q<1 fijo, `F(k,q)→0` cuando k crece: barrera multiplicativa de consentimiento, no fallo intrínseco de especialización. Si `q_k=1−a/k`, la disponibilidad límite es `2/(2+exp(a))`.

V165 confirma 3 de 4 condiciones dentro de sus intervalos bootstrap95. El caso k=8,q=.8 predijo 32.4027% y observó 32.7326%, con intervalo [32.4985%,32.9652%] que **EXCLUYE** el valor teórico; esta discrepancia quedó conservada en el auditor V166, no se ha borrado. V165B se diseñó después, con 128 poblaciones NUEVAS y 80000 decisiones cada una: k=8,q=.8 terminó 32.45235%, intervalo [32.34007%,32.56409%], que **SÍ** contiene 32.4027%. Esto respalda compatibilidad del resultado bajo un nuevo experimento de robustez, sin convertir una réplica seleccionada después del desacuerdo en preconfirmación ni garantizar ausencia de sesgo desconocido.

## Resultado 6 — La correlación de los avisos institucionales cambia drásticamente la escala (V167)
Manteniendo idéntica probabilidad individual q=.8 de mensaje favorable, comparamos mecanismos de información: unanimidad de votos independientes (ρ=0), mezcla de señales comunes en el 25% de los encuentros (ρ=.25), o una única señal pública común que reciben todos los donantes (ρ=1). La probabilidad de aprobación conjunta para el grupo es

`Q(k,q,ρ)=(1−ρ)q^(k−1)+ρq`.

Por sustitución en la expresión de renovación, la completitud estacionaria es

`F(k,q,ρ)= [2Q k/(k−1)]/[1+2Q k/(k−1)]`.

Con q=.8, 64 nuevas poblaciones pareadas por k, 30 grupos, 20000 oportunidades por mundo y 4000 de calentamiento:

| k | Aprobaciones independientes | 25% señal común | Señal pública común |
|---|---:|---:|---:|
| 4 | 57.814% | 60.978% | 68.075% |
| 8 | 32.393% | 44.981% | 64.679% |
| 12 | 16.040% | 36.626% | 63.417% |

La diferencia público menos independiente en mundo pareado es: k4 +10.2617 pp (bootstrap95 [10.0550,10.4677]); k8 +32.2860 pp [31.8951,32.6662]; k12 +47.3773 pp [46.9330,47.8049]. Las nueve fórmulas calculadas en aritmética racional y sus nueve intervalos bootstrap95 se auditaron en `V167A_EXACT_CERTIFICATION_AUDIT.json` y todas contienen la predicción. Mismo programa de selección y las mismas semillas por cada k en los tres esquemas de señal. Los votos reales no emergen como preferencias: son eventos de transmisión estocástica exógenos; la correlación positiva aumenta la probabilidad de que un paquete llegue completo.

Cuando ρ>0 es fijo, la aprobación conjunta se aproxima a ρq y `F(k,q,ρ)→2ρq/(1+2ρq)`. Cuando ρ=0 y q<1, la fracción tiende a cero. La diferencia es una propiedad elemental de señales perfectamente correlacionadas frente a Bernoulli independientes, aplicada aquí a una cadena de mantenimiento funcional, **no prueba de que centralizar o publicar mensajes favorezca siempre la coordinación humana**. Una señal común errónea puede crear errores simultáneos y el modelo no estudia sus costes ni su legitimidad.

Criterio cuantitativo de viabilidad de esta familia para un objetivo `F>=F*`: exigir `Q >= F*/(2[k/(k−1)](1−F*))`. Por ejemplo, k8 y F*=.60 requieren Q≥.65625. Con unanimidad independiente ello requiere q≥(.65625)^(1/7)≈.94160; con señal común basta q≥.65625. No extrapolar fuera del juego artificial.

## Auditorías y trazabilidad
Protocolos V157, V159, V160, V161, V162, V163, V164, V165, V165B y V167 redactados antes de su cohorte respectiva, pero sus preguntas están motivadas por resultados anteriores y son post hoc dentro de una misma familia conceptual. Cada protocolo mantiene los falsadores, las reglas del estimando y la unidad de 64 mundos; V165B tiene 128. V166 completó 39 comprobaciones técnicas y conservó la única desviación de CI95 de V165. V167A completó 9 chequeos en nueve celdas con aritmética racional, verificación de misma cohorte de mundos en todos los ρ y todos los CI teóricos cubiertos. Los conteos de decisiones y grupos NO constituyen observaciones humanas ni muestras de estudios independientes. Los JSON no deben sobrescribirse.

## Examen adversarial de originalidad
La contribución de compromisos condicionales está ya estudiada en:
- Gürdal, Gürerk, Kaçamak & Kart, 2024, *How to increase and sustain cooperation in public goods games: Conditional commitments via a mediator*, Journal of Economic Behavior & Organization, doi:10.1016/j.jebo.2024.106789. El artículo combina teoría y experimentación humana; los datos están disponibles **a solicitud**, no se han usado aquí.
- Oechssler, Reischmann & Sofianos, 2022, *The conditional contribution mechanism for repeated public goods – The general case*, Journal of Economic Theory, doi:10.1016/j.jet.2022.105488. Hay mecanismo condicional convergente y datos de laboratorio.
- Heitzig, 2025, *Provision of Public Goods via Unilateral but Mutually Conditional Commitments—Mechanism, Equilibria, and Learning*, Games, doi:10.3390/g16060058.
- Oechssler, 2026, *Solving Dilemma Games with Evolving Conditional Commitments*, preliminary discussion paper, enero 27. Precede la mayoría de nuestras preguntas sobre evolución de compromisos.
- Itao & Kaneko, 2025, *Self-organized institutions in evolutionary dynamical-systems games*, PNAS, doi:10.1073/pnas.2500960122, formaliza instituciones endógenas y regularidad temporal.
- Tilbury & Radke, 2025, *Adaptive Reward Sharing to Enhance Learning in the Context of Multiagent Teams*, Reinforcement Learning Journal, vol.6 pp1480–1495, aprendizaje descentralizado simultáneo de política y reparto de recompensa.

Las propiedades de cadenas de Markov, correlación de señales y umbrales de aprobación son resultados clásicos; **V157–V167 no justifican afirmar una teoría social original ni validar el VSM de Stafford Beer**. Lo que sí se ha construido es un ejemplo matemáticamente cerrado y computacionalmente reproducible de disponibilidad colectiva sin equilibrio individual y sus condiciones de escala, con dos tecnologías de simulación.

## Decisión científica de continuidad
**Mantener el CT2 vigente de 61/100 sin incremento por esta campaña.** La referencia anterior a 55/100 era un hito histórico de V141–V149; el registro principal fue elevado posteriormente a 61/100 por la línea V150–V153 de otros experimentos. El salto a 2/3 exige romper la circularidad entre mecanismo diseñado y fenómeno simulado. Siguiente candidata central, susceptible de falsación: permitir que agentes con información local PRIVADA descubran por aprendizaje qué precio, contrato y régimen de cumplimiento conviene establecer, junto con composición de equipos y oficios, usando un rival competente de MARL con reward sharing aprendible; comparar transferencia a otros k y B, señales públicas con coste y ruido común (para que la correlación tenga efectos adversos también), reemplazo generacional y resultados humanos sobre adopción de compromisos, sin confundir sus operaciones con nuestros roles artificiales. Si el sistema únicamente aprende un protocolo ya descubierto por el diseñador o sobrevive solo con contrafactuales perfectos, declarar esta rama controlada como resultado técnico, no científico original.

Este informe es una síntesis verificable de archivos JSON y referencias públicas; los trabajos sobre humanos constituyen *antecedentes externos*, no datos incorporados a las simulaciones.
