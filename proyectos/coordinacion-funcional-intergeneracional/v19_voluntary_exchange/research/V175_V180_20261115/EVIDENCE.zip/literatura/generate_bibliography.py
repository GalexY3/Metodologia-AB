"""Compile the cumulative evidence-index and BibTeX from verified source metadata."""
from pathlib import Path
import json,re
p=Path(__file__).resolve().parent
d=json.loads((p/"references_verified.json").read_text(encoding="utf8"))
R=d["references"]
assert len(R)==d["number_verified"]==len({z["id"] for z in R})
assert all(z["url"].startswith("https://") for z in R)
TH=[("SOCIOLOGIA","Sociología, solidaridad, estructura y micromecanismos"),("INSTITUCIONES","Instituciones y autogobierno"),("SISTEMAS","Viabilidad y cibernética"),("FILOSOFIA_SOCIAL","Señales y convenciones"),("RECIPROCIDAD","Reciprocidad estratégica"),("EVOLUCION","Evolución de cooperación"),("NORMAS","Sanciones y normas"),("EMPIRICO","Estudios con humanos"),("DIVISION","División del trabajo"),("INTERCAMBIO","Intercambio de recursos"),("INCENTIVOS","Incentivación distribuida"),("MARL_ROLES","Roles MARL"),("DIVERSIDAD","Diversidad conductual"),("PARAMETROS","Parámetros compartidos y privados"),("MARL","Algoritmos MARL"),("METODOLOGIA","Causalidad y reproducibilidad"),("REPLICACION","Simuladores comparadores")]
md=["# Base bibliográfica acumulativa de cooperación y división del trabajo",
f"Revisión {d['review_date']}: **{len(R)} fuentes verificadas bibliográficamente; {len(d['pending'])} pendientes**.",
"Esta es una revisión de alcance exploratorio, no una revisión sistemática. Las fichas editoriales, resúmenes e índices no equivalen a lectura completa del texto. La base structured references_verified.json contiene alcance de verificación por obra.",
"Regla permanente: conservar también artículos que resuelvan una pregunta propia; sus mecanismos se integran en el marco teórico y en los controles. Las aportaciones originales solamente se pueden reclamar después de comparaciones adversariales.",
""]
for theme,heading in TH:
 group=sorted((z for z in R if z["theme"]==theme),key=lambda x:(x["year"],x["id"]))
 if not group:continue
 md+=["## "+heading,""]
 for z in group:
  link="https://doi.org/"+z["doi"] if z.get("doi") else z["url"]
  md.append(f"**{z['authors']} ({z['year']}).** [{z['title']}]({link}); *{z['container']}*.")
  md.append("**Contribución conocida.** "+z["contribution"])
  md.append("**Relación con nuestro trabajo.** "+z["our_experiments"]+". **Restricción para originalidad.** "+z["novelty_constraint"]+".")
  md.append("**Comprobación:** "+z["verification"]+"; lectura íntegra = "+("sí" if z["full_text_reviewed"] else "no")+".")
  md.append("")
if d["pending"]:
 md+=["## Entradas pendientes",""]
 for z in d["pending"]:md.append("- "+z["authors"]+" ("+str(z["year"])+") "+z["title"])
md+=["## Materiales y protocolo posterior","",
"Yaman et al. 2023 [material Dryad](https://doi.org/10.5061/dryad.dv41ns24r) es candidato para una replicación externa con profesiones desigualmente atractivas y sanciones.",
"Priorizar lectura integral de Yaman 2023, DiCo 2024, HARL 2024, Garbus-Pollack 2024, SND 2025, así como obras sociológicas específicas. Preparar extracción de variables, intervenciones, rivales y licencias antes de reimplementar.",
"Documentar modelos siguiendo [ODD 2020](https://doi.org/10.18564/jasss.4259); publicar checkpoints, seeds y resultados negativos como evidencia, no seleccionar mejores trayectorias."]
(p/"BIBLIOGRAFIA_ACUMULATIVA_20261114.md").write_text("\n\n".join(md)+"\n",encoding="utf8")
books={"Ostrom1990","Beer1994","Skyrms2010","Durkheim1893","Schelling1978","Coleman1990","Hedstrom2005"}
bib=[]
for z in R:
 typ="book" if z["id"] in books else "misc" if "arxiv preprint" in z["container"].lower() else "article"
 fields=[("author",z["authors"].replace("; "," and ")),("title",z["title"]),("year",str(z["year"])),("publisher" if typ=="book" else "journal",z["container"])]
 if z.get("doi"):fields.append(("doi",z["doi"]))
 fields.append(("url",z["url"]))
 bib.append("@"+typ+"{"+z["id"]+",\n"+",\n".join("  "+k+" = {"+str(v).replace("&",r"\&")+"}" for k,v in fields)+"\n}\n")
(p/"references.bib").write_text("\n".join(bib),encoding="utf8")
assert len(re.findall(r"^@(article|book|misc)\{([^,]+),",(p/"references.bib").read_text(encoding="utf8"),re.M))==len(R)
print("BIB_RENDER_OK",len(R),"pending",len(d["pending"]))
