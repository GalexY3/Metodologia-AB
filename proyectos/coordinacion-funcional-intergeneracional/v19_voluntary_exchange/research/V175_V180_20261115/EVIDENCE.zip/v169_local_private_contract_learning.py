"""V169: independent private tabular learners for contracts, gifts, prices, roles.
No hidden planner for PRIVATE. Fixed teams and an exogenous enforceable contract menu.
"""
from __future__ import annotations
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
W=64;G=30;K=4;H=4000
M=W*G
DELTA=.75;SWITCH=.015;GIFT_COST=.12
PRICES=np.array([np.nan,0.,.1,.2,.4,.8,1.6,2.2])
ARMS=("UNILATERAL_PRIVATE","BINDING_PRIVATE","GIFT_ONLY_PRIVATE",
      "UNBOUND_PRIVATE","FIXED_PRICE_PRIVATE","BINDING_TEAM","ORACLE_CONTRACT")
SEEDS=tuple(16900000+int.from_bytes(hashlib.sha256(
    f"V169-local-learn-world-{i}".encode()).digest()[:4],"little"
)%1000000000 for i in range(W))
assert len(set(SEEDS))==W
OTHER=np.array([[j for j in range(4) if j!=i] for i in range(K)])
ROW=np.arange(M)
COL=np.arange(K)[None,:]
def init():
    roles=np.empty((W,G,K),np.int8)
    for w,s in enumerate(SEEDS):
        rng=np.random.default_rng(s)
        roles[w]=np.array([rng.permutation([0,0,1,2]) for _ in range(G)])
    roles=roles.reshape(M,K)
    assert np.all(np.sort(roles,axis=1)==np.array([0,0,1,2])[None,:])
    dup=np.argsort(np.where(roles==0,np.arange(K),100),axis=1)[:,:2]
    assert np.all(roles[ROW[:,None],dup]==0)
    return roles,dup
def stage(roles,give,recipients,price,changed):
    # Permitted transfer only from the 3 noncritical workers to the single
    # new role3, conditional on actual delivery by this recipient.
    critical=(roles==3)
    alive=(recipients>=0)
    owner=np.maximum(recipients,0)
    active=alive&give[ROW,owner].astype(bool)
    transfer=np.zeros((M,K),float)
    fee=np.where(active,price/3,0)
    transfer+=np.where(critical,0.,-fee[:,None])
    transfer[ROW,owner]+=np.where(active,price,0)
    # Goods received, excluding own production and duplicated categories.
    own=(roles[...,None]==np.arange(K)[None,None,:])
    delivered=own*give[...,None]
    count=delivered.sum(1,keepdims=True)
    received=(count-delivered>0)&~own
    d=received.sum(-1)
    food=.20+.55*d/3+.25*(d==3)-GIFT_COST*give-DELTA*critical-SWITCH*changed
    full=np.sort(roles,axis=1)==np.arange(K)[None,:]
    good_group=full.all(1)&np.all(d==3,axis=1)
    reward=food+transfer
    assert np.max(np.abs(transfer.sum(1)))<1e-9
    assert np.isfinite(reward).all()
    return reward,dict(group_success=good_group,
        group_complete=full.all(1),critical=critical,
        donation=give.astype(bool),received=d,
        accepted=(recipients>=0),income=transfer)
def physical_parity():
    from v133_voluntary_donation_shock import payoff
    rng=np.random.default_rng(169069)
    maxerr=0
    for trial in range(500):
        n=32
        r=rng.integers(0,K,size=(n,K)).astype(int)
        g=rng.integers(0,2,size=(n,K)).astype(int)
        sw=rng.integers(0,2,size=(n,K)).astype(float)
        # Direct model stage against independent established V133 physical engine.
        ones=np.tile(np.eye(K,dtype=int)[None,:,:],(n,1,1))
        gift_matrix=g[:,:,None]*(1-ones)
        ref=payoff(r.reshape(n,1,4),gift_matrix.reshape(n,1,4,4),0,
                   sw.reshape(n,1,4))[:,:, :].reshape(n,K)-(.75-.5)*(r==3)
        received=np.zeros(n,dtype=int)-1
        got,_=stage_wrapper(r,g,sw)
        maxerr=max(maxerr,float(np.max(np.abs(ref-got))))
        assert maxerr<1e-12,(trial,maxerr)
    return maxerr
def stage_wrapper(r,g,sw):
    global M,ROW
    oldM,oldROW=M,ROW
    M=len(r);ROW=np.arange(M)
    try:return stage(r,g,np.full(M,-1,int),np.zeros(M),sw)
    finally:M,ROW=oldM,oldROW

def choose(q,eps,rng):
    n=len(q)
    jitter=rng.random(q.shape)*1e-8
    greedy=(q+jitter).argmax(-1)
    explore=rng.random(n)<eps
    return np.where(explore,rng.integers(q.shape[-1],size=n),greedy)
def experiment(arm,episodes):
    t0=time.perf_counter()
    roles0,duplicates=init()
    rng=np.random.default_rng(169101)
    q_offer=np.full((M,K,len(PRICES)),.20)
    q_accept=np.full((M,K,len(PRICES),2),.20)
    q_gift=np.full((M,K,2),.20)
    q_role=np.full((M,K,2),.20)
    incentive_team=arm=="BINDING_TEAM"
    contract_arm=arm in ("BINDING_PRIVATE","GIFT_ONLY_PRIVATE",
                "UNBOUND_PRIVATE","FIXED_PRICE_PRIVATE","BINDING_TEAM",
                "ORACLE_CONTRACT")
    forced_donations=arm in ("BINDING_PRIVATE","GIFT_ONLY_PRIVATE",
                "FIXED_PRICE_PRIVATE","BINDING_TEAM","ORACLE_CONTRACT")
    offer0=0
    history=[]
    window=[]
    offercount=np.zeros((M,),int)
    q_snapshots={}
    for t in range(episodes):
        eps=.3-.25*min(t,3000)/3000 if t<3000 else .02
        roles=roles0.copy()
        candidate=duplicates[ROW,rng.integers(0,2,size=M)]
        donors=OTHER[candidate]
        owner=np.full(M,-1,int)
        price=np.zeros(M,float)
        act_offer=np.zeros(M,int)
        contract=np.zeros(M,bool)
        acc_choice=np.zeros((M,3),int)
        role_choice=np.zeros(M,int)
        proposed=np.zeros(M,bool)
        if arm=="ORACLE_CONTRACT":
            act_offer[:]=3; price[:]=.2;proposed[:]=True
            contract[:]=True;owner=candidate.copy()
        elif contract_arm:
            candidate_Q=q_offer[ROW,candidate,:]
            if arm=="GIFT_ONLY_PRIVATE":
                allowed=np.array([0,1])
            elif arm=="FIXED_PRICE_PRIVATE":
                allowed=np.array([0,3])
            else:
                allowed=np.arange(len(PRICES))
            picked=choose(candidate_Q[:,allowed],eps,rng)
            act_offer=allowed[picked]
            proposed=act_offer!=0
            price=np.where(proposed,np.nan_to_num(PRICES[act_offer]),0.)
            target_q=q_accept[ROW[:,None],donors,act_offer[:,None]]
            voted=choose(target_q.reshape(M*3,2),eps,rng).reshape(M,3)
            acc_choice=voted
            contract=proposed&voted.astype(bool).all(axis=1)
            owner=np.where(contract,candidate,-1)
        else:
            # No coordination mechanism; one duplicated worker can learn
            # privately to change occupation without transfers.
            role_choice=choose(q_role[ROW,candidate],eps,rng)
            owner=np.where(role_choice==1,candidate,-1)
        if np.any(owner>=0):
            roles[ROW[owner>=0],owner[owner>=0]]=3
        give_choice=choose(q_gift.reshape(M*K,2),eps,rng).reshape(M,K)
        gives=give_choice.copy()
        if forced_donations:
            gives[contract]=1
        change=(roles!=roles0).astype(float)
        reward,meta=stage(roles,gives,
            np.where(contract,owner,-1) if contract_arm else np.full(M,-1,int),
            np.where(contract,price,0.),change)
        if arm=="ORACLE_CONTRACT":
            # No Q update for omniscient upper benchmark.
            pass
        else:
            signal=reward.mean(1,keepdims=True)*np.ones_like(reward) if incentive_team else reward
            alpha=.12
            if contract_arm:
                qprev=q_offer[ROW,candidate,act_offer]
                q_offer[ROW,candidate,act_offer]=qprev+alpha*(signal[ROW,candidate]-qprev)
                seen=np.broadcast_to(proposed[:,None],(M,3)).reshape(-1)
                idx_m=np.repeat(ROW,3)[seen]
                idx_s=donors.reshape(-1)[seen]
                idx_o=np.repeat(act_offer,3)[seen]
                idx_c=acc_choice.reshape(-1)[seen]
                pp=q_accept[idx_m,idx_s,idx_o,idx_c]
                q_accept[idx_m,idx_s,idx_o,idx_c]=pp+alpha*(signal[idx_m,idx_s]-pp)
            else:
                pp=q_role[ROW,candidate,role_choice]
                q_role[ROW,candidate,role_choice]=pp+alpha*(signal[ROW,candidate]-pp)
            free_gifts=np.ones((M,K),bool)
            if forced_donations:free_gifts[contract]=False
            im=np.broadcast_to(ROW[:,None],(M,K))[free_gifts]
            ids=np.broadcast_to(COL,(M,K))[free_gifts]
            aa=give_choice[free_gifts]
            p=q_gift[im,ids,aa]
            q_gift[im,ids,aa]=p+alpha*(signal[im,ids]-p)
        full=meta["group_success"].reshape(W,G).mean(1)
        mean_reward=reward.reshape(W,G,K).mean((1,2))
        gift_rate=gives.reshape(W,G,K).mean((1,2))
        accepted=contract.reshape(W,G).mean(1)
        price_act=(price*contract).reshape(W,G).sum(1)/np.maximum(contract.reshape(W,G).sum(1),1)
        critical=(roles==3).reshape(W,G,K).mean((1,2))
        raw=dict(step=t+1,world_success=full.tolist(),
           world_reward=mean_reward.tolist(),world_gift=gift_rate.tolist(),
           world_contract=accepted.tolist(),world_price_accepted=price_act.tolist(),
           world_critical=critical.tolist(),
           proposals_per_world=proposed.reshape(W,G).sum(1).tolist(),
           veto_per_world=(proposed&~contract).reshape(W,G).sum(1).tolist(),
           mean_success=float(full.mean()),
           mean_reward=float(mean_reward.mean()),
           mean_gift=float(gift_rate.mean()),
           mean_accepted=float(accepted.mean()),
           mean_accepted_price=float(price_act.mean()))
        window.append(raw)
        if (t+1)%250==0 or t+1==episodes:
            recent=window[-min(250,len(window)):]
            val={key:np.mean([z[key] for z in recent],axis=0).tolist()
                 for key in ("world_success","world_reward","world_gift",
                             "world_contract","world_price_accepted","world_critical")}
            val.update(step=t+1,
                successful_groups=float(np.mean([z["mean_success"] for z in recent])),
                private_return=float(np.mean([z["mean_reward"] for z in recent])),
                gift_rate=float(np.mean([z["mean_gift"] for z in recent])),
                contract_rate=float(np.mean([z["mean_accepted"] for z in recent])),
                paid_price=float(np.mean([z["mean_accepted_price"] for z in recent])))
            history.append(val)
            print("V169",arm,t+1,"succ",round(val["successful_groups"],4),
                "reward",round(val["private_return"],4),
                "gift",round(val["gift_rate"],4),
                "agreements",round(val["contract_rate"],4),
                "meanprice",round(val["paid_price"],3),
                "sec",round(time.perf_counter()-t0,1),flush=True)
            if len(window)>500:window=window[-500:]
    last=history[-2:] if len(history)>=2 else history[-1:]
    final={k:np.mean([z[k] for z in last],axis=0).tolist()
           for k in ("world_success","world_reward","world_gift",
                     "world_contract","world_price_accepted","world_critical")}
    final.update({'mean_'+k:float(np.mean(v)) for k,v in list(final.items())})
    return dict(arm=arm,history=history,final=final,
        independent_private_learners=not incentive_team and arm!="ORACLE_CONTRACT",
        interval_learning_only_own_utility=not incentive_team,
        q_offer_final_summary=[float(np.mean(q_offer[:,: ,j])) for j in range(len(PRICES))],
        q_offer_final_std=[float(np.std(q_offer[:,:,j])) for j in range(len(PRICES))],
        total_episodes=episodes,elapsed=time.perf_counter()-t0)
def bootstrap(rows,episodes):
    rng=np.random.default_rng(169090)
    d={z["arm"]:np.asarray(z["final"]["world_success"]) for z in rows}
    comparisons={}
    for aa,bb in (
       ("BINDING_PRIVATE","UNILATERAL_PRIVATE"),
       ("BINDING_PRIVATE","GIFT_ONLY_PRIVATE"),
       ("BINDING_PRIVATE","UNBOUND_PRIVATE"),
       ("BINDING_PRIVATE","FIXED_PRICE_PRIVATE"),
       ("BINDING_TEAM","BINDING_PRIVATE"),
       ("ORACLE_CONTRACT","BINDING_PRIVATE")):
        dif=d[aa]-d[bb]
        bs=dif[rng.integers(0,W,size=(10000,W))].mean(1)
        comparisons[f"{aa}_minus_{bb}"]=dict(mean=float(dif.mean()),
             percentile_bootstrap95=np.quantile(bs,[.025,.975]).tolist(),
             n_worlds=W,positive=int((dif>0).sum()),negative=int((dif<0).sum()))
    return comparisons
def main():
    p=argparse.ArgumentParser()
    p.add_argument("--smoke",action="store_true")
    pa=p.parse_args()
    print("V169_PARITY",physical_parity(),flush=True)
    rows=[]
    for arm in (ARMS if not pa.smoke else ARMS[:3]):
        rows.append(experiment(arm,H if not pa.smoke else 30))
    if pa.smoke:
        print("V169_SMOKE_PASS",flush=True)
        return
    obj=dict(date="2026-11-15",study="V169 private local tabular institutional learning",
        seeds=SEEDS,n_population_worlds=W,n_groups=G,n_agents=G*K,
        episodes=H,original_roles_exogenously_three_professions=True,
        fixed_membership=True,contract_action_menu_exogenous=True,
        mandatory_gifts_only_if_individuals_accepted_contract=True,
        donation_choice_learned_outside_contract=True,
        individual_acceptance_policy_learned=True,
        role3_occupation_choice_learned_through_offer_or_unilateral=True,
        contract_price_learned=True,
        n_worlds_not_number_of_independent_train_seeds=True,
        controls=ARMS,results=rows,comparisons=bootstrap(rows,H),
        code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        prereg_sha256=hashlib.sha256((ROOT/"PREREG_V169_PRIVATE_LEARNED_CONTRACT_GAME.md").read_bytes()).hexdigest(),
        prior_art=["Oechssler 2022 CCM","Gurdal 2024 conditional commitments","Itao Kaneko 2025 institutions"],
        research_grade_not_2of3=True)
    out=ROOT/"results/V169_PRIVATE_LEARNED_CONTRACTS_64W.json"
    assert not out.exists()
    out.write_text(json.dumps(obj,indent=2),encoding="utf8")
    print("V169_DONE",out,flush=True)
if __name__=="__main__":main()
