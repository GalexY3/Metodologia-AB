## Código publicado, riesgo material y generalización entre agentes

15/11/2026. Objetivo de investigación ACTIVO. La puntuación histórica61 no cambia. No se acredita2/3. La nueva rama de comunicación no tiene puntuación ordinal asignada. El avance de este bloque consiste en resolver incertidumbres con código original y controles causales, no en sumar ejecuciones como originalidad.

### Resultado científico y límites

Se ejecutó el código original de Yaman2023 y un port independiente de su física; se verificaron1.200ajustes originales y6.480vidas nuevas. Se falsó una explicación fuerte del rendimiento basada en el orden de transferencias y ataques. La reproducción de pastura conserva cooperación elevada en varias condiciones, aunque difiere de los valores de entrenamiento seleccionados. El piloto solicitado de grokking distingue un receptor que generaliza tarde con diccionario fijo de dos agentes privados que no llegan a memorizar toda la tarea. No se ha demostrado una nueva forma de grokking colectivo ni una institución que surja de intereses contrapuestos.

### V182: el antecedente se reproduce con reservas concretas

Fuente primaria: [Yaman etal2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC10598450/) y su [archivo CC0](https://zenodo.org/records/8401555),252.169.955bytes,SHA256c152434d267e7992284077183456d853569bef74cb4ff7e95c7a86689f553b45. Los autores declaran la selección de normas con fitness de grupo y el cumplimiento obligatorio. Los papeles sí se aprenden individualmente; los agentes no deciden privadamente adoptar todo el régimen normativo.

El archivo de common pasture contiene dos discrepancias ejecutadas en Octave: GA cambia `socialNorm`,pero el simulador lee `genotype`; su fitness usa suma de signos en vez de contar reglas,bonificando reglas negativas. Modificar solo socialNorm deja idénticas curvas y papeles; modificar genotype sí cambia la trayectoria. Con una regla negativa usada, el fitness archivado ejecutable es3.718757254918 frente a3.318757254918 que daríaL0. En cambio, los1.200ajustes.mat reconstruyen exactamente la fórmulaL0,error máximo5.33e-15. Además usan nombres anteriores de campos. Esto prueba desalineación del paquete publicado; no prueba que el artículo haya usado el código defectuoso ni que su resultado cooperativo sea falso.

El portNumba mantiene la rejilla,optimismoQ=10,actualización elegida,exploraciónepsilon0,órdenes cartesianos aleatorios,liquidez sin deuda y orden de operaciones. Se contrastaron51salidas con seis fixtures del MATLAB original ejecutado en Octave. El código de replay cambia solo nombres de función y proveedores de aleatoriedad; los originales permanecen intactos. V183 añade63comprobaciones. Son verificaciones técnicas internas, no confirmaciones sociológicas externas.

### V183: el canal material existe, pero no explica una ventaja grande

Preregistro[c1ecde0](https://github.com/GalexY3/Metodologia-AB/commit/c1ecde092d02140c18b13c54498b7477232a3d52).300normas settlement de lambda0/.2,cincoentornos,30semillas originales compartidas entre contextos,ocho vidas nuevas por norma y dos órdenes temporales:4.800vidas. Se conservó cada norma y se volvió a aprender papeles. Los ataques se movieron antes de las transferencias en un brazo con cintas acopladas; los demás mecanismos no cambiaron.

Para un ingreso r,transferencias netasdelta y supervivenciaA,la diferencia material inmediata respecto a redistribuir después del ataque es sum(A*delta). Su esperanza condicional es p*sum(P*delta),siendoPprotección y sum(delta)=0. Es una identidad de conservación; no una descomposición del efecto completo del aprendizaje ni un teorema novedoso de seguros.

El efecto primario ORIGINAL−ATTACK_FIRST fue0.054893,ICbootstrap jerárquico95[0.014270,0.100594],por debajo del margen previo.25. El gate FALLA. El bootstrap remuestrea30bloques originales y ocho semillas de vida; no trata180procesos ni4.800vidas como estudios independientes. Los controlesp=0coinciden,el error máximo de conservación es1.31e-12y el de identidad1.43e-14. Se cierra la hipótesis de una gran ventaja por este orden en estas normas; no se reoptimiza para rescatarla.

![Reproducción y control temporal](../results/FIG_V182_V184_REPRODUCTION.png)

### V184: qué asignación de parámetros concuerda mejor

Preregistro[d359009](https://github.com/GalexY3/Metodologia-AB/commit/d359009eb01363a2404b71c7d799acc23dd42021). Se reevaluaron300normas de pastura,cuatro vidas nuevas por asignación yT=5000. En tres entornos el intercambio de parámetros no cambia nada: sus resultados se reutilizan,dejando1.680vidas únicas frente a2.400celdas tabuladas.

La asignación del código naturalGrowth=.5*env(1),workerGrowth=.5*env(2) produjoRMSE0.842605frente a4.026717del intercambio,en120normas asimétricas. La diferencia media absoluta entre asignaciones fue2.558093. Pasa el criterio descriptivo de correspondencia. No identifica de forma única el generador histórico. La selección de normas sobre vidas ruidosas y las diferencias de versión siguen siendo explicaciones posibles para la discrepancia residual. No hemos reproducido una evolución del GA de pastura corregido.

### V185: un piloto que evita llamar colectivo a cualquier aumento tardío

Preregistro[662da03](https://github.com/GalexY3/Metodologia-AB/commit/662da03333d936ad71e941fef3f5bec885a0bc34). Emisor observaa,receptorobservabymensaje,yobjetivoes(a+b)mod31. El emisor aprendeREINFORCEsolo desde acierto propio; el receptor aprende con su etiqueta de resultado. Parámetros,observaciones y gradientes separados. El interés común,el canal y las funciones de emisor/receptor están impuestos. No es evidencia de cooperación motivacional emergente.

387pares de entrenamiento y574de test,con pares invertidos en el mismo conjunto,evitan memorizar una interacción y probar su copia invertida.30.000actualizaciones por ejecución; dos semillas de descubrimiento,no confirmación.

| Semilla | Condición | Trainfinal | Testfinal | t_mem | t_gen |
|---|---|---:|---:|---:|---:|
| 185115 | FIXED_PROTOCOL | 100.00% | 97.91% | 600 | 13600 |
| 185115 | INDEPENDENT_COMM | 91.47% | 27.35% | None | None |
| 185116 | FIXED_PROTOCOL | 100.00% | 99.30% | 600 | 11600 |
| 185116 | INDEPENDENT_COMM | 96.38% | 62.02% | None | None |

El receptor con código fijo cumple el criterio previo de generalización tardía en ambas historias. Los pares independientes no alcanzan train99%; por ello se cancelaron las cuatro congelaciones condicionales previstas. No son pruebas negativas ejecutadas. El emisor termina casi determinista con24/28símbolos. La precisión óptima en todos los pares queda limitada a24/31y28/31; el techo condicionado al test es85.89%/93.38%. Es un límite informacional clásico,no una teoría nueva.

Un análisis posthoc encuentra que cada receptor ya alcanza la precisión de entrenamiento óptima para el diccionario codicioso aprendido y que ninguna sustitución unilateral de símbolo mejora la precisión actual del emisor. Esto es una afirmación restringida sobre el clasificador y la tabla final; no prueba Nash en todo el espacio de políticas. Intercambiar receptores entre semillas o permutar mensajes reduce el rendimiento cerca del azar,lo que sí apoya uso causal de convenciones específicas,sin demostrar generalización colectiva.

![Generalización tardía](../results/FIG_V185_DELAYED_GENERALIZATION.png)

### V186: presupuesto igualado e intervención sobre las colisiones

Preregistro[4164292](https://github.com/GalexY3/Metodologia-AB/commit/4164292c0d32adcb58c2d9ce4e944427578b8da2). Se añaden30.000actualizaciones a cada historia en tres brazos:continuación conjunta,diccionario aprendido congelado y reparación biyectiva externa. La reparación cambia solo7/3asignaciones,sin mirar etiquetas o test. No es un nuevo algoritmo autónomo. Los tres brazos parten del mismo receptor y optimizador.10.000actualizaciones históricas se reprodujeron con pesos,baseline y RNG exactamente iguales antes de las continuaciones; no se contabilizan como datos nuevos.

| Historia | Continua conjunto | Código aprendido fijo | Reparación externa | Gate previo |
|---|---:|---:|---:|---|
| 185115 | 35.19% | 8.89% | 98.78% | True |
| 185116 | 71.25% | 22.30% | 100.00% | True |

El gate de suficiencia específica exige reparación>=95%y ventaja>=10puntos frente a ambos rivales en las dos historias.Resultado conjunto:True. Las seis continuaciones reutilizan dos historias; no equivalen a seis réplicas independientes. La reparación demuestra capacidad bajo una intervención cuando funciona; por sí sola no explica cómo los agentes crearían espontáneamente ese código.

![Intervención causal](../results/FIG_V186_CAUSAL_BOTTLENECK.png)

### Originalidad y siguiente incertidumbre decisiva

Los resultados se enfrentan a antecedentes fuertes: [LIO](https://proceedings.neurips.cc/paper_files/paper/2020/hash/ad7ed5d47b9baceb12045a929e7e2f66-Abstract.html)ya aprende incentivos privados; [Power](https://arxiv.org/abs/2201.02177)ya demuestra grokking individual; [Chaabouni](https://aclanthology.org/2020.acl-main.407/)ya analiza generalización comunicativa; [Lowe](https://ifaamas.org/Proceedings/aamas2019/pdfs/p693.pdf)exige controles causales de comunicación. Los estados de agrupación parcial y su dependencia del aprendizaje son clásicos en [juegos de señales](https://pmc.ncbi.nlm.nih.gov/articles/PMC4113927/). [Spike etal](https://pmc.ncbi.nlm.nih.gov/articles/PMC5412673/)identifican olvido y presión contra ambigüedad como componentes conocidos. No convertir nuestro diagnóstico en una supuesta primera demostración de esos principios.

Antes de reclamar un fenómeno colectivo nuevo,el rival pertinente es un aprendiz privado competente de convenciones,incluyendo refuerzo tipoRoth–Erev con mecanismos documentados contra agrupación parcial. También falta demostrar si una transición necesita reorganización de varios aprendices en vez de generalización del receptor sobre un código ya estable. Es una incertidumbre concreta que el piloto hace medible; no está resuelta por aumentar el número de semillas del mismoREINFORCE.

### Registro, integridad y evaluación AB

V182es auditoría posthoc del antecedente;V183yV184se preregistraron antes de vidas nuevas;V185antes de entrenar;V186antes de nuevas continuaciones. El parser inicial que omitía structs MATLAB se invalidó y se preserva. Un problema de restauración deByteTensorRNGenCUDAafectaba al helper de congelacionesV185,no ejecutadas; se corrigió enV186y el replay histórico fue exacto. No se alteraron resultados para resolver discrepancias.

El índice yHEADlocales del usuario se preservan; la publicación usa una rama propia. El CT2histórico61yN2=N3=0permanecen. Ningún principio informacional,gate técnico o reproducción externa se convierte automáticamente en originalidad acreditada. La investigación global sigue activa. El gráfico de referencia mantiene su historia previa, sin asignar puntos numéricos ficticios a la nueva rama.

![CT2 histórico, escala completa y ampliada](../results/FIG_CT2_V175_V180.png)
