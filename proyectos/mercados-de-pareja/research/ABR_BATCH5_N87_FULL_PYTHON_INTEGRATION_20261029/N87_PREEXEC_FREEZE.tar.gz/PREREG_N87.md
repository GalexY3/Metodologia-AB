# N87 — A–J preregistration before outcome execution (2026-10-29)

**Status: PRE-EXECUTION FREEZE.** No results or sample outcome counts are read before code and this contract are committed to research branch. This is a genuine ESBM original Python execution over *synthetic* agents, NOT human confirmatory work. No claim 1/3–3/3 or CT2 lift.

A. **Question:** Can we instrument the exact original ESBM v2 simulated formed/dissolved/active spells, represent cohort-specific right censoring and compute a common restricted horizon without changing even one legacy output across all 6 seeds x 10 scenarios?

B. **Rivals:** old completed-only mean `duration_completed_mean` versus discrete Kaplan–Meier RMST on durations/events; exact legacy equality is a stronger test than merely passing isolated unit tests. N86 helper provides baseline estimator, no comparison to human study models.

C. **Estimands:** formation-cohort `RMST_(16-start)` conditional on entering that cohort, and pooled `RMST_4` only among relationships formed at ticks 0–12 with 4 observable steps. Do not pool 16-tick followup across late entrants; no unrestricted mean or human causal effect. Events at 4 are treated as administratively censored for the RMST4 restriction. Report excluded late cohorts.

D. **Inputs and technical design:** Original `esbm_dynamic.py`, uploaded by user, SHA256 `f7e6b84000720cbdf2ee0800c2b10d136185facd00e4622756cbb5f8d8254d0b`, Git blob `5fc9f63fd44ff81ce9ff6c900ba6bf24153356f2`; N86 `survival_metrics.py` blob `580895c7f0a00217664ffdc437d722a6bb045c3b`. Code `instrument_survival.py` uses SHA-gated exact unique textual anchors, captures every synthetic spell at dissolution and at end. Never edit the historical v2 file. Execute 60 original vs instrumented `simulate` runs on identical seed/scenario configurations and same PRNG. Test source SHA rejection, staged entries, censor and event boundaries, heterogeneous hazards and cohort balances.

E. **Freeze and reproducibility:** `instrument_survival.py`, `test_integration.py`, this `PREREG_N87.md`, and SHA256/Git blob references are committed in one PRE-EXECUTION Git commit. Local code run must match frozen Git blobs byte-for-byte. Execute in an isolated temporary copied workspace; list Python/numpy/networkx versions. This is *not* a clean dependency rebuild, only fresh workdir with system packages.

F. **Success metrics:** 10 integration tests (5 cohort artificial, 5 full 60-run), 9 inherited N86 tests passing; 60 out of 60 exact equality on all old result keys including `track`; invariant formed = dissolved + active; cohort count and event balance; at least one staggered start and one heterogeneous hazard; 4-tick RMST in [1,4] for all eligible. If any fails, record INVALID, do not silently repair after freeze.

G. **Negative controls:** deliberately modified v2 source fails SHA; administrative censor earlier than cohort horizon rejected; event at cohort censor boundary rejected; no synthetic relationships handled; entries at 15 ticks assigned only 1-tick observation and excluded from 4-tick pooled estimator.

H. **Causal/empirical validity:** known artificial behavior, no external human data, no novelty claim. KM within cohort assumes defensible censoring, which would require additional assessment in human studies. Original Python effect of scenario on formation composition makes RMST comparisons conditional on actually formed pairs, not causal effect on people.

I. **Registration:** one technical AB-R cycle N87 at most; if valid, update P-UNION-DURATION qualitative with no new human source, ledger and one CT2 point equal to 7; maturity increase only for directly verified integration and reproducibility. The earlier N86 helper still not integrated into the historical source file, which stays unchanged.

J. **Decision:** valid only if code freeze is verified and real execution passes tests; save full aggregate JSON, test receipt, hashes, Git commit. Otherwise N87 unspent/invalid with rationale. Any subsequent cycles N88–N106 remain reserved and not authorized for execution in this tranche; STOP_R5 on human confirmation, no main merge, authors, licenses, OSF/Essex/Stanford/Gist or SSJY.
