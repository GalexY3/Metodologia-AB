"""Frozen tests for ESBM v2 survival instrumentation; synthetic only."""
from pathlib import Path
import unittest
from instrument_survival import cohort_survival, compare_all_runs, load_instrumented


class TestCohortMath(unittest.TestCase):
    def test_staggered_three_cohorts(self):
        examples = [(0, 1, 1, .10), (0, 16, 0, .20),
                    (8, 2, 1, .30), (8, 8, 0, .40), (15, 1, 0, .50)]
        r = cohort_survival(examples, formed=5, dissolved=2, active=3, steps=16)
        self.assertEqual(r['cohort_count'], 3)
        self.assertEqual([c['n'] for c in r['cohorts']], [2, 2, 1])
        self.assertEqual(r['common_eligible_n'], 4)
        self.assertEqual(r['excluded_late_cohort_n'], 1)
        self.assertAlmostEqual(r['common_horizon_rmst'], 2.75)
        self.assertEqual(r['hazard_distinct_n'], 5)
        self.assertAlmostEqual(r['cohorts'][-1]['rmst_within_cohort_followup'], 1.0)

    def test_censor_early_disallowed_for_admin_model(self):
        with self.assertRaises(AssertionError):
            cohort_survival([(0, 5, 0, .1)], 1, 0, 1, 16)

    def test_event_at_administrative_horizon_disallowed(self):
        with self.assertRaises(AssertionError):
            cohort_survival([(0, 16, 1, .1)], 1, 1, 0, 16)

    def test_no_formed_relations(self):
        r = cohort_survival([], 0, 0, 0, 16)
        self.assertIsNone(r['common_horizon_rmst'])

    def test_original_sha_rejects_modified_source(self):
        from tempfile import TemporaryDirectory
        with TemporaryDirectory() as tmp:
            p = Path(tmp) / 'esbm_dynamic.py'
            p.write_text('# deliberately not the frozen source\n')
            with self.assertRaises(ValueError):
                load_instrumented(p)


class TestFullSimulation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import os
        cls.report = compare_all_runs(Path(os.environ['N87_ORIGINAL_SOURCE']))

    def test_all_60_legacy_runs_unchanged(self):
        self.assertTrue(self.report['legacy_all_60_bitwise_value_equal'])
        self.assertEqual(self.report['runs'], 60)

    def test_formation_rupture_censor_balance(self):
        for row in self.report['cohort_observations']:
            diag = row['survival']
            self.assertEqual(diag['formed'], diag['dissolved'] + diag['active_end'])

    def test_staggered_entry_present(self):
        self.assertTrue(any(row['survival']['cohort_count'] > 1
                            for row in self.report['cohort_observations']))

    def test_heterogeneous_hazard_present(self):
        self.assertTrue(any(row['survival']['hazard_distinct_n'] > 1
                            for row in self.report['cohort_observations']))

    def test_common_horizon_computable(self):
        self.assertTrue(any(row['survival']['common_horizon_rmst'] is not None
                            for row in self.report['cohort_observations']))
        for row in self.report['cohort_observations']:
            x = row['survival']['common_horizon_rmst']
            if x is not None:
                self.assertGreaterEqual(x, 1)
                self.assertLessEqual(x, 4)


if __name__ == '__main__':
    unittest.main(verbosity=2)
