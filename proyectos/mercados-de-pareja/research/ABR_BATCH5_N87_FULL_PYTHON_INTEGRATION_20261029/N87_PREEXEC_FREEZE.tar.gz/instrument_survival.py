"""ESBM v2 source-preserving survival instrumentation; SHA-pinned, no source mutation.

This uses the genuine upstream function and inserts only event logging / diagnostics.
Simulation evidence remains synthetic. No license or data access changes.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
from survival_metrics import km_rmst

ORIGINAL_SHA256 = 'f7e6b84000720cbdf2ee0800c2b10d136185facd00e4622756cbb5f8d8254d0b'
EXPECTED_RUNS = 60
COMMON_HORIZON = 4


def checked_replace(text: str, before: str, after: str) -> str:
    if text.count(before) != 1:
        raise ValueError('Expected exactly one occurrence of source anchor: ' + repr(before))
    return text.replace(before, after, 1)


def cohort_survival(spells: list[tuple[int, int, int, float]], formed: int,
                    dissolved: int, active: int, steps: int) -> dict:
    """Event and administrative censor histories are internal synthetic summaries."""
    if len(spells) != formed or sum(z[2] for z in spells) != dissolved:
        raise AssertionError('relation creation/dissolution mismatch')
    if sum(z[2] == 0 for z in spells) != active:
        raise AssertionError('active relation censor count mismatch')
    if len(spells) != len(set((t, i) for i, (t, _, _, _) in enumerate(spells))):
        raise AssertionError('duplicate synthetic spell index')
    cohorts = []
    for start in sorted(set(z[0] for z in spells)):
        group = [z for z in spells if z[0] == start]
        tau = steps - start
        for _, duration, event, _ in group:
            if not (1 <= duration <= tau) or event not in (0, 1):
                raise AssertionError('invalid spell time or event')
            if event and duration == tau:
                raise AssertionError('breakup at administrative cutoff')
            if not event and duration != tau:
                raise AssertionError('all original ESBM censored bonds must reach end of simulation')
        if tau >= 2:
            stats = km_rmst([z[1] for z in group], [z[2] for z in group], tau)
            rmst = stats['rmst']
        else:
            rmst = 1.0
        cohorts.append({'start_tick': start, 'maximum_followup_ticks': tau,
                        'n': len(group), 'events': sum(z[2] for z in group),
                        'censored': sum(not z[2] for z in group),
                        'rmst_within_cohort_followup': rmst})
    early = [z for z in spells if z[0] <= steps - COMMON_HORIZON]
    truncated = [(min(z[1], COMMON_HORIZON), int(z[2] == 1 and z[1] < COMMON_HORIZON))
                 for z in early]
    summary = km_rmst([z[0] for z in truncated], [z[1] for z in truncated], COMMON_HORIZON) if truncated else None
    hazards = sorted(set(round(z[3], 12) for z in spells))
    return {'formed': formed, 'dissolved': dissolved, 'active_end': active,
            'cohort_count': len(cohorts), 'cohorts': cohorts,
            'common_horizon': COMMON_HORIZON, 'common_eligible_n': len(early),
            'excluded_late_cohort_n': formed - len(early),
            'common_horizon_rmst': summary['rmst'] if summary else None,
            'common_horizon_events': summary['events'] if summary else 0,
            'hazard_distinct_n': len(hazards),
            'hazard_min': min(hazards) if hazards else None,
            'hazard_max': max(hazards) if hazards else None,
            'no_original_person_rows_exported': True}


def load_instrumented(original: Path) -> SimpleNamespace:
    payload = original.read_bytes()
    if hashlib.sha256(payload).hexdigest() != ORIGINAL_SHA256:
        raise ValueError('ESBM v2 source SHA256 changed')
    src = payload.decode('utf-8')
    src = checked_replace(src, ' key_pairs=set()\n', ' key_pairs=set()\n survival_spells=[]\n')
    src = checked_replace(src,
        '    duration=t-int(start[i]); completed_duration.append(duration)\n',
        '    duration=t-int(start[i]); completed_duration.append(duration)\n'
        '    survival_spells.append((int(start[i]), duration, 1, float(h)))\n')
    src = checked_replace(src,
        ' censored_durations=[STEPS-int(start[i]) for i in range(N) if partner[i]>i]\n',
        ' censored_durations=[STEPS-int(start[i]) for i in range(N) if partner[i]>i]\n'
        ' for i in range(N):\n'
        '  j=int(partner[i])\n'
        '  if j>i:\n'
        "   hazard=min(.90, (.12+.065*(norm[i]!=norm[j])+.004*abs(int(age[i])-int(age[j])))*config['hazard_mult'])\n"
        '   survival_spells.append((int(start[i]), STEPS-int(start[i]), 0, float(hazard)))\n'
        ' survival_diagnostic=cohort_survival(survival_spells, formed, dissolved, active_pairs, STEPS)\n')
    src = checked_replace(src, ' return result\n',
                          " result['survival_diagnostic']=survival_diagnostic\n return result\n")
    g = {'__name__': 'esbm_v3_instrumented', '__file__': str(original),
         'cohort_survival': cohort_survival}
    exec(compile(src, str(original) + ':instrumented', 'exec'), g)
    return SimpleNamespace(**g)


def compare_all_runs(original: Path) -> dict:
    import importlib.util
    spec = importlib.util.spec_from_file_location('esbm_dynamic_v2_frozen', original)
    original_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original_mod)
    v3 = load_instrumented(original)
    rows = []
    for seed in original_mod.SEEDS:
        for name, config in original_mod.SCENARIOS.items():
            before = original_mod.simulate(seed, name, config)
            after = v3.simulate(seed, name, config)
            diag = after.pop('survival_diagnostic')
            if before != after:
                changed = [k for k in before if before[k] != after.get(k)]
                raise AssertionError('Legacy metrics or trajectories changed: ' + repr((seed, name, changed)))
            if not (diag['formed'] == before['total_relationships_formed']
                    and diag['dissolved'] == before['total_dissolutions']
                    and diag['active_end'] == before['active_partnerships_end']):
                raise AssertionError('Failed formation/dissolution/censor invariant')
            if diag['cohort_count'] != len(diag['cohorts']):
                raise AssertionError('cohort count mismatch')
            if sum(c['n'] for c in diag['cohorts']) != diag['formed']:
                raise AssertionError('cohort size mismatch')
            rows.append({'seed': seed, 'scenario': name,
                         'duration_completed_mean_legacy': before['duration_completed_mean'],
                         'survival': diag})
    if len(rows) != EXPECTED_RUNS:
        raise AssertionError('expected 60 original seed-scenario runs')
    return {'status': 'FROZEN_INTEGRATION_QA_SYNTHETIC',
            'original_sha256': ORIGINAL_SHA256, 'runs': len(rows),
            'legacy_all_60_bitwise_value_equal': True,
            'cohort_observations': rows,
            'warning': 'Coarse discrete RMST conditional on formation start. Not independent censoring proof, not human results.'}


if __name__ == '__main__':
    import sys
    report = compare_all_runs(Path(sys.argv[1]))
    print(json.dumps(report, indent=2, ensure_ascii=False))
