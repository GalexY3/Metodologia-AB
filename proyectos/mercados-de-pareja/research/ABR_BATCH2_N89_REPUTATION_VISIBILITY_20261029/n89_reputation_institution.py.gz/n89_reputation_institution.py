"""AB-R N89: test visibility assumptions of rejection-generated reputation.

No original/human data; independent source-guarded edit of exact original ESBM v2.
Code must be frozen and SHA-verified in private GitHub BEFORE invoking execute().
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
from pathlib import Path
import numpy as np

ORIGINAL_SHA = 'f7e6b84000720cbdf2ee0800c2b10d136185facd00e4622756cbb5f8d8254d0b'
SEEDS = [101, 211, 307, 401, 503, 601]
CONTEXTS = ['mixed_random', 'popularity_ranking', 'institutional_segregation', 'explicit_norm_preference']
MODES = ['global', 'witness', 'silent']
EXTRA = ['reputation_replies_total', 'reputation_applied_replies',
         'reputation_nonwitness_candidate_replies', 'reputation_witness_candidate_replies',
         'reputation_rejections_recorded', 'reputation_scope']

def patch_source(original: str) -> str:
    edits = [
      ('def simulate(seed, name, config):', 'def simulate(seed, name, config, signal_scope="global"):'),
      (' public_score=np.zeros(N,dtype=float)\n',
       ' public_score=np.zeros(N,dtype=float)\n known_reject=np.zeros((N,N),dtype=bool)\n'
       ' reputation_replies_total=0; reputation_applied_replies=0\n'
       ' reputation_nonwitness_candidate_replies=0; reputation_witness_candidate_replies=0\n'
       ' reputation_rejections_recorded=0\n'),
      ("    rep_effect=public_score[i] if config['public'] else 0\n",
       "    if config['public']:\n"
       "     reputation_replies_total+=1\n"
       "     if public_score[i]<0 and known_reject[j,i]: reputation_witness_candidate_replies+=1\n"
       "     if public_score[i]<0 and not known_reject[j,i]: reputation_nonwitness_candidate_replies+=1\n"
       "    rep_effect=public_score[i] if config['public'] and (signal_scope=='global' or (signal_scope=='witness' and known_reject[j,i])) else 0\n"
       "    if rep_effect<0: reputation_applied_replies+=1\n"),
      ("     if config['public']:public_score[i]=max(-1.8,public_score[i]-.08)\n",
       "     if config['public']:\n"
       "      public_score[i]=max(-1.8,public_score[i]-.08)\n"
       "      known_reject[j,i]=True\n"
       "      reputation_rejections_recorded+=1\n"),
      (" assert formed-dissolved==active_pairs,(name,seed,formed,dissolved,active_pairs)\n",
       " result.update(reputation_replies_total=reputation_replies_total,\n"
       "               reputation_applied_replies=reputation_applied_replies,\n"
       "               reputation_nonwitness_candidate_replies=reputation_nonwitness_candidate_replies,\n"
       "               reputation_witness_candidate_replies=reputation_witness_candidate_replies,\n"
       "               reputation_rejections_recorded=reputation_rejections_recorded,\n"
       "               reputation_scope=signal_scope)\n"
       " assert formed-dissolved==active_pairs,(name,seed,formed,dissolved,active_pairs)\n")
    ]
    code = original
    for old, new in edits:
        if code.count(old)!=1:
            raise AssertionError('source anchor mismatch: '+repr(old[:70])+': '+str(code.count(old)))
        code=code.replace(old,new,1)
    compile(code, '<frozen_original_derived>', 'exec')
    return code

def strip_extra(d):
    return {k:v for k,v in d.items() if k not in EXTRA}

def strip_silent(d):
    return {k:v for k,v in strip_extra(d).items() if k not in ('scenario','final_public_reputation_penalty_mean')}

def execute(path: str):
    original_bytes=Path(path).read_bytes()
    if hashlib.sha256(original_bytes).hexdigest()!=ORIGINAL_SHA:
        raise AssertionError('original source sha mismatch')
    original=original_bytes.decode('utf-8')
    modified=patch_source(original)
    real={'__name__':'esbm_original_n89', '__file__':str(Path(path).resolve())}
    instr={'__name__':'esbm_instrumented_n89', '__file__':str(Path(path).resolve())}
    exec(compile(original,path,'exec'),real)
    exec(compile(modified,'<instrumented_n89>','exec'),instr)
    primary=[]
    contexts=[]
    for context in CONTEXTS:
        for seed in SEEDS:
            config=dict(real['SCENARIOS'][context], public=True,private=False)
            arms={mode:instr['simulate'](seed,'public_rejection_signal',config,signal_scope=mode) for mode in MODES}
            for mode,a in arms.items():
                assert a['total_relationships_formed']-a['total_dissolutions']==a['active_partnerships_end']
                assert 0<=a['reputation_applied_replies']<=a['reputation_replies_total']
                assert a['reputation_witness_candidate_replies']+a['reputation_nonwitness_candidate_replies']<=a['reputation_replies_total']
                if mode=='silent': assert a['reputation_applied_replies']==0
                if mode=='witness': assert a['reputation_applied_replies']==a['reputation_witness_candidate_replies']
                if mode=='global': assert a['reputation_applied_replies']==a['reputation_witness_candidate_replies']+a['reputation_nonwitness_candidate_replies']
            # Sham: original public scenario semantics (same code, policy/context modified in sensitivity cases).
            original_public=real['simulate'](seed,'public_rejection_signal',config)
            if strip_extra(arms['global'])!=original_public:
                raise AssertionError('SHAM ORIGINAL NOT IDENTICAL: '+context+':'+str(seed))
            # All consequences of public-score updates disabled = original mixed_random-type context.
            original_no_signal=real['simulate'](seed,context,dict(config,public=False))
            if strip_silent(arms['silent'])!=strip_silent(original_no_signal):
                raise AssertionError('SILENT NO-SIGNAL BASELINE NOT IDENTICAL '+context+':'+str(seed))
            rec=dict(context=context,seed=seed,
                formed={m:arms[m]['total_relationships_formed'] for m in MODES},
                active={m:arms[m]['active_partnerships_end'] for m in MODES},
                responses={m:arms[m]['total_positive_responses'] for m in MODES},
                applied={m:arms[m]['reputation_applied_replies'] for m in MODES},
                nonwitness_candidates={m:arms[m]['reputation_nonwitness_candidate_replies'] for m in MODES},
                witness_candidates={m:arms[m]['reputation_witness_candidate_replies'] for m in MODES},
                rejections={m:arms[m]['reputation_rejections_recorded'] for m in MODES},
                exact_original_global=True,exact_no_public_silent=True)
            contexts.append(rec)
            if context=='mixed_random': primary.append(rec)
    assert len(contexts)==24 and len(primary)==6
    # Manipulation check: truly globally exposed rejects and different reputation effects.
    global_nonwitness=sum(x['nonwitness_candidates']['global'] for x in primary)
    assert global_nonwitness>0, 'No nonwitness opportunities; mechanism not testable'
    def aggregate(records):
        return {'n':len(records),
          'mean_formed':{m:round(float(np.mean([x['formed'][m] for x in records])),6) for m in MODES},
          'mean_active':{m:round(float(np.mean([x['active'][m] for x in records])),6) for m in MODES},
          'mean_responses':{m:round(float(np.mean([x['responses'][m] for x in records])),6) for m in MODES},
          'mean_applied_penalties':{m:round(float(np.mean([x['applied'][m] for x in records])),6) for m in MODES},
          'sum_nonwitness_opportunities_global':sum(x['nonwitness_candidates']['global'] for x in records),
          'paired_global_minus_witness_formed': [x['formed']['global']-x['formed']['witness'] for x in records],
          'paired_global_minus_witness_active': [x['active']['global']-x['active']['witness'] for x in records],
          'paired_global_minus_silent_formed':[x['formed']['global']-x['formed']['silent'] for x in records],
          'paired_global_minus_silent_active':[x['active']['global']-x['active']['silent'] for x in records]}
    return {
      'design':'N89_PRE_FREEZE_SAME_PRNG_PUBLIC_SIGNAL_SCOPE_COMPARISON',
      'synthetic_only':True,'original_human_observations':0,'code_source_sha256':ORIGINAL_SHA,
      'n_runs_instrumented':72,'n_runs_unmodified_original_sham':24,'n_runs_original_no_public_baseline':24,
      'n_total_simulations':120,'n_sham_global_equal':24,'n_sham_silent_equal':24,
      'primary':aggregate(primary),
      'sensitivity':{context:aggregate([x for x in contexts if x['context']==context]) for context in CONTEXTS},
      'per_seed_context_records':contexts,
      'limitations':'Toy 144 agents, 16 ticks, endogenous match risksets; no empirical reputation exposure measurements; post-rejection witness matrix only sees own rejections; public broadcast is a modelling assumption, not proof of social diffusion.'
    }

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--source',required=True)
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    result=execute(args.source)
    Path(args.out).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('sensitivity','per_seed_context_records')},indent=2))
