"""N92 pre-frozen mechanism-discriminating ablation of within-tick visibility rankings.
Run: python n92_snapshot_test.py --original /mnt/data/esbm_dynamic.py --n91 /mnt/data/n91_preflight/n91_relabel_audit.py --out RESULT.json
No source-file mutation, all artificial actors only.
"""
from __future__ import annotations
import argparse,hashlib,importlib.util,json,types
from pathlib import Path
import numpy as np

SOURCE_SHA='f7e6b84000720cbdf2ee0800c2b10d136185facd00e4622756cbb5f8d8254d0b'
N91_SHA='2ea5b39520f86dd35d760f6d29ddac26ff839afa1289aebbb034cf3ceeb2e791'
SEEDS=[101,211,307,401,503,601]
SNAPSHOT_OLD="scores+=-1.4*np.log1p(seen[candidates])"
SNAPSHOT_NEW="scores+=-1.4*np.log1p(seen_tick_start[candidates])"
TICK_OLD=" for t in range(STEPS):\n"
TICK_NEW=" for t in range(STEPS):\n  seen_tick_start=seen.copy()\n"

def import_file(path,name,sha):
    path=Path(path);assert hashlib.sha256(path.read_bytes()).hexdigest()==sha, 'File SHA failure: '+str(path)
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def snapshot_module(path):
    source=Path(path).read_text()
    assert source.count(SNAPSHOT_OLD)==1 and source.count(TICK_OLD)==1
    assert "seen[j]+=1" in source
    patched=source.replace(TICK_OLD,TICK_NEW,1).replace(SNAPSHOT_OLD,SNAPSHOT_NEW,1)
    assert patched.count(SNAPSHOT_OLD)==0 and patched.count(SNAPSHOT_NEW)==1
    namespace=types.ModuleType('esbm_snapshot_N92')
    namespace.__file__=str(path)
    exec(compile(patched,str(path)+'_snapshot','exec'),namespace.__dict__)
    return namespace

def simulate_with(mod,config,seed,name,p):
    real_people=mod.people
    try:
        mod.people=lambda seed,p=p:p
        return mod.simulate(seed,name,config)
    finally:mod.people=real_people

def run(source,n91_path):
    n91=import_file(n91_path,'frozen_n91_relabel',N91_SHA)
    base=import_file(source,'esbm_v2_source',SOURCE_SHA)
    snap=snapshot_module(source)
    assert base.SEEDS==SEEDS and snap.N==base.N==144
    rows=[]; controls=[]
    # Negative: identical implementations under policy without balance term.
    for scenario in ['mixed_random','popularity_ranking']:
        for seed in SEEDS:
            o=base.simulate(seed,scenario,base.SCENARIOS[scenario]);s=snap.simulate(seed,scenario,snap.SCENARIOS[scenario]);assert o==s
            controls.append({'seed':seed,'scenario':scenario,'equal':True})
    for seed in SEEDS:
        p=n91.inputs_of_original(base,seed)
        cfg=base.SCENARIOS['visibility_balancing']
        old_original=base.simulate(seed,'visibility_balancing',cfg)
        for label,perm in n91.perms(seed):
            pp=n91.reindex(p,perm);n91.inverse_checks(p,pp,perm)
            old=simulate_with(base,cfg,seed,'visibility_balancing',pp)
            new=simulate_with(snap,cfg,seed,'visibility_balancing',pp)
            if label=='identity':assert old==old_original,'Identity source mismatch'
            for q in (old,new):
                assert q['total_relationships_formed']-q['total_dissolutions']==q['active_partnerships_end']
            rows.append({'seed':seed,'label':label,'original_formed':old['total_relationships_formed'],'snapshot_formed':new['total_relationships_formed'],'original_gini':old['receiver_impression_gini'],'snapshot_gini':new['receiver_impression_gini'],'original_active':old['active_partnerships_end'],'snapshot_active':new['active_partnerships_end'],'original_impressions':old['total_impressions'],'snapshot_impressions':new['total_impressions'],'original_track':old['track'],'snapshot_track':new['track'],'original_all':old,'snapshot_all':new})
    assert len(rows)==24 and len(controls)==12
    by=[]
    for seed in SEEDS:
        group=[x for x in rows if x['seed']==seed]
        center=next(x for x in group if x['label']=='identity')
        for v in group:
            by.append({'seed':seed,'label':v['label'],'original_delta_formed_vs_identity':v['original_formed']-center['original_formed'],'snapshot_delta_formed_vs_identity':v['snapshot_formed']-center['snapshot_formed'],'original_full_changed':v['original_all']!=center['original_all'],'snapshot_full_changed':v['snapshot_all']!=center['snapshot_all'],'original_delta_gini':v['original_gini']-center['original_gini'],'snapshot_delta_gini':v['snapshot_gini']-center['snapshot_gini'],'snapshot_minus_original_formed':v['snapshot_formed']-v['original_formed']})
    relabeled=[x for x in by if x['label']!='identity']
    original_changes=sum(x['original_delta_formed_vs_identity']!=0 for x in relabeled)
    snapshot_changes=sum(x['snapshot_delta_formed_vs_identity']!=0 for x in relabeled)
    result={'schema':'N92_snapshot_mechanism_v1','source_sha256':SOURCE_SHA,'N91_script_sha256':N91_SHA,'simulations':60,'negative_control_exact':len(controls),'old_relabel_formed_changed':original_changes,'snapshot_relabel_formed_changed':snapshot_changes,'snapshot_full_changed':sum(x['snapshot_full_changed'] for x in relabeled),'snapshot_vs_original_identity_mean_formed':sum(x['snapshot_minus_original_formed'] for x in by if x['label']=='identity')/6,'snapshot_vs_original_identity_mean_gini':sum(v['snapshot_gini']-v['original_gini'] for v in rows if v['label']=='identity')/6,'by_seed':by,'negative_controls':controls,'code_unchanged':True,'interpretation':'A source-guarded intervention in the within-tick visibility score; purely synthetic, not external human evidence.'}
    return result

if __name__=='__main__':
    arg=argparse.ArgumentParser();arg.add_argument('--original',required=True);arg.add_argument('--n91',required=True);arg.add_argument('--out',required=True);z=arg.parse_args()
    result=run(z.original,z.n91)
    Path(z.out).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('by_seed','negative_controls')},ensure_ascii=False,indent=2))
