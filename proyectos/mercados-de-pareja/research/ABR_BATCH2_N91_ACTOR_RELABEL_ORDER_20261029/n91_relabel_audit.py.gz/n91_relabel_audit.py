"""N91 source-guarded actor relabel invariance audit. FROZEN BEFORE OUTCOMES.

Run: python n91_relabel_audit.py --source /path/esbm_dynamic.py --out output.json
No modification to source. No human data.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json
from pathlib import Path
import numpy as np

SOURCE_SHA = 'f7e6b84000720cbdf2ee0800c2b10d136185facd00e4622756cbb5f8d8254d0b'
SCENARIOS = ['mixed_random','popularity_ranking','institutional_segregation','private_rejection_learning','public_rejection_signal','visibility_balancing']
NEGATIVE_CONTROLS = SCENARIOS[:-1]
SEEDS = [101,211,307,401,503,601]
N=144

def load_original(path):
    file=Path(path)
    assert hashlib.sha256(file.read_bytes()).hexdigest()==SOURCE_SHA, 'Source hash mismatch'
    spec=importlib.util.spec_from_file_location('n91_esbm_original',file)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    assert mod.N==N and mod.STEPS==16 and mod.SEEDS==SEEDS
    return mod

def inputs_of_original(mod,seed):
    p=mod.people(seed)
    # Only the UPPER TRIANGLE is used in the original ESBM for hazard & match
    # because the matching loop uses sorted original IDs. Copy it symmetrically
    # so that relabelled participants keep exactly the same dyad shocks.
    for key in ('u_hazard','u_match'):
        m=p[key].copy()
        ix=np.tril_indices(N,-1)
        m[:,ix[0],ix[1]]=m[:,ix[1],ix[0]]
        p[key]=m
    return p

def reindex(p,new_to_old):
    result={}
    for k,x in p.items():
        if x.ndim==1:result[k]=x[new_to_old].copy()
        elif x.ndim==3:result[k]=x[:,new_to_old,:][:,:,new_to_old].copy()
        else:raise AssertionError((k,x.shape))
    return result

def inverse_checks(orig,permuted,perm):
    inv=np.argsort(perm)
    for key,x in orig.items():
        restored=permuted[key][inv] if x.ndim==1 else permuted[key][:,inv,:][:,:,inv]
        if not np.array_equal(x,restored):raise AssertionError('Failed to restore '+key)
    for key in ('u_hazard','u_match'):
        if not np.array_equal(permuted[key],permuted[key].swapaxes(1,2)):
            raise AssertionError('Pairwise shock orientation not preserved: '+key)

def perms(seed):
    yield 'identity',np.arange(N)
    yield 'reverse',np.arange(N-1,-1,-1)
    yield 'shuffle_1',np.random.default_rng(910000+seed).permutation(N)
    yield 'shuffle_2',np.random.default_rng(920000+seed).permutation(N)

def run(source):
    mod=load_original(source)
    person_original=mod.people
    output=[]
    for seed in SEEDS:
        p_base=inputs_of_original(mod,seed)
        # Source has been adapted only for relabelling: identity must match unmodified v2
        for scenario in SCENARIOS:
            cfg=mod.SCENARIOS[scenario]
            mod.people=person_original
            reference=mod.simulate(seed,scenario,cfg)
            assert reference==mod.simulate(seed,scenario,cfg)
            for label,perm in perms(seed):
                permuted=reindex(p_base,perm)
                inverse_checks(p_base,permuted,perm)
                try:
                    mod.people=lambda s,p=permuted: p
                    actual=mod.simulate(seed,scenario,cfg)
                finally:mod.people=person_original
                legacy_fields=('total_impressions','total_proposals','total_positive_responses','total_relationships_formed','total_dissolutions','active_partnerships_end','receiver_impression_gini','mean_active_pairs','group_same_exposure','group_same_new_couples')
                # actor-ID-independent summaries, plus full outputs except seed/scenario (dict ordering irrelevant)
                diffs={k:actual[k]-reference[k] if isinstance(actual[k],(int,float)) and isinstance(reference[k],(int,float)) else None for k in legacy_fields}
                same=(actual==reference)
                output.append({'seed':seed,'scenario':scenario,'permutation':label,'same_all_result_fields':same,'diffs':diffs,'reference':{k:reference[k] for k in legacy_fields},'actual':{k:actual[k] for k in legacy_fields}})
    # Hard gates preregistered: identity matches full original 36/36.
    assert all(o['same_all_result_fields'] for o in output if o['permutation']=='identity')
    assert len(output)==144 and len({(r['seed'],r['scenario'],r['permutation']) for r in output})==144
    assert all(int(o['actual']['total_relationships_formed'])-int(o['actual']['total_dissolutions'])==int(o['actual']['active_partnerships_end']) for o in output)
    # For balanced exposure our a-priori nonempty mechanism gate is access of later senders
    # to earlier senders' seen counts; observed at original source lines 105 and 109.
    assert "scores+=-1.4*np.log1p(seen[candidates])" in Path(source).read_text()
    assert "seen[j]+=1" in Path(source).read_text()
    scenarios=[]
    for scenario in SCENARIOS:
        a=[o for o in output if o['scenario']==scenario and o['permutation']!='identity']
        scenarios.append({'scenario':scenario,'permuted_runs':len(a), 'full_output_differences':sum(not x['same_all_result_fields'] for x in a), 'formed_mean_delta':sum(x['diffs']['total_relationships_formed'] for x in a)/len(a),'formed_min_delta':min(x['diffs']['total_relationships_formed'] for x in a),'formed_max_delta':max(x['diffs']['total_relationships_formed'] for x in a),'gini_mean_delta':sum(x['diffs']['receiver_impression_gini'] for x in a)/len(a),'outcome_formed_change_count':sum(x['diffs']['total_relationships_formed']!=0 for x in a)})
    return {'schema':'N91_relabel_v1','source_sha256':SOURCE_SHA,'run_count':len(output),'baseline_simulations':6*6,'permutations':4,'identity_exact':36,'results':output,'by_scenario':scenarios,'controls':{'identity_36_of_36':True,'array_roundtrip_all':True,'pair_shocks_symmetrized_upper_original_preserved':True,'balance_formed_minus_dissolved':True},'negative_controls_expected_to_be_invariant':NEGATIVE_CONTROLS,'interpretation':'Technical actor-label order sensitivity, not empirical human effect or scientific novelty.'}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    res=run(args.source)
    Path(args.out).write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'run_count':res['run_count'],'by_scenario':res['by_scenario'],'controls':res['controls']},ensure_ascii=False,indent=2))
