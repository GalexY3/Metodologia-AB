"""N90: frozen adversarial audit of same-tick updating in private rejection learning."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

ORIGINAL_SHA='f7e6b84000720cbdf2ee0800c2b10d136185facd00e4622756cbb5f8d8254d0b'
SEEDS=[101,211,307,401,503,601]
CONTEXTS=['mixed_random','popularity_ranking','institutional_segregation','explicit_norm_preference']
MODES=('immediate','next_tick','silent')
EXTRA={'private_mode','private_same_tick_attempts','private_rejections','private_lagged_updates'}

def rewrite(original):
    edits=[
      ('def simulate(seed, name, config):','def simulate(seed, name, config, update_timing="immediate"):'),
      (' private_bias=np.zeros(N,dtype=float)\n',
       ' private_bias=np.zeros(N,dtype=float)\n same_tick_attempts=0; private_rejections=0; private_lagged_updates=0\n'),
      (' for t in range(STEPS):\n',
       ' for t in range(STEPS):\n  tick_start_bias=private_bias.copy()\n  private_pending=np.zeros(N,dtype=int)\n'),
      ("    send_util=-.85+1.6*(q[j]-.5)+config['same_pref']*same-.012*gap+private_bias[i]\n",
       "    if update_timing=='immediate' and private_bias[i]>tick_start_bias[i]: same_tick_attempts+=1\n"
       "    effective_bias=0 if update_timing=='silent' else private_bias[i]\n"
       "    send_util=-.85+1.6*(q[j]-.5)+config['same_pref']*same-.012*gap+effective_bias\n"),
      ("     if config['private']:private_bias[i]=min(.80,private_bias[i]+.08)\n",
       "     if config['private']:\n"
       "      private_rejections+=1\n"
       "      if update_timing=='next_tick': private_pending[i]+=1\n"
       "      else: private_bias[i]=min(.80,private_bias[i]+.08)\n"),
      ("  samples.append(dict(t=t,singles=len(available),risk_edges=possible_edges,impressions=len(impressions),proposals=tick_proposals,reciprocals=len(mutual),new_pairs=len(pairs),active_pairs=ongoing))\n",
       "  samples.append(dict(t=t,singles=len(available),risk_edges=possible_edges,impressions=len(impressions),proposals=tick_proposals,reciprocals=len(mutual),new_pairs=len(pairs),active_pairs=ongoing))\n"
       "  if config['private'] and update_timing=='next_tick':\n"
       "   private_bias=np.minimum(.80,private_bias+.08*private_pending)\n"
       "   private_lagged_updates+=int(private_pending.sum())\n"),
      (' assert formed-dissolved==active_pairs,(name,seed,formed,dissolved,active_pairs)\n',
       ' result.update(private_mode=update_timing, private_same_tick_attempts=same_tick_attempts,\n'
       '               private_rejections=private_rejections, private_lagged_updates=private_lagged_updates)\n'
       ' assert formed-dissolved==active_pairs,(name,seed,formed,dissolved,active_pairs)\n')
    ]
    code=original
    for old,new in edits:
        assert code.count(old)==1, 'anchor count mismatch '+repr(old[:60])+':'+str(code.count(old))
        code=code.replace(old,new,1)
    compile(code,'<n90_instrument>','exec')
    return code

def standard(d):return {k:v for k,v in d.items() if k not in EXTRA}
def silent_standard(d):return {k:v for k,v in standard(d).items() if k not in ('scenario','final_private_aspiration_bias_mean')}

def execute(path):
    raw=Path(path).read_bytes(); assert hashlib.sha256(raw).hexdigest()==ORIGINAL_SHA
    source=raw.decode('utf8')
    local={'__file__':str(Path(path).resolve()),'__name__':'original_n90'}
    patched={'__file__':str(Path(path).resolve()),'__name__':'patched_n90'}
    exec(compile(source,path,'exec'),local)
    exec(compile(rewrite(source),'<n90_instrument>','exec'),patched)
    records=[]
    for context in CONTEXTS:
     for seed in SEEDS:
      cfg=dict(local['SCENARIOS'][context],private=True,public=False)
      arms={mode:patched['simulate'](seed,'private_rejection_learning',cfg,update_timing=mode) for mode in MODES}
      real=local['simulate'](seed,'private_rejection_learning',cfg)
      assert standard(arms['immediate'])==real,('immediate original-sham failed',context,seed)
      no_private=local['simulate'](seed,context,dict(cfg,private=False))
      assert silent_standard(arms['silent'])==silent_standard(no_private),('no-private silent-sham failed',context,seed)
      for m,v in arms.items():
       assert v['total_relationships_formed']-v['total_dissolutions']==v['active_partnerships_end']
       assert v['private_rejections']>=v['private_lagged_updates']>=0
       if m=='next_tick': assert v['private_lagged_updates']==v['private_rejections']
       if m!='next_tick':assert v['private_lagged_updates']==0
       if m!='immediate': assert v['private_same_tick_attempts']==0
      records.append({'context':context,'seed':seed,'formed':{m:arms[m]['total_relationships_formed'] for m in MODES},
        'active':{m:arms[m]['active_partnerships_end'] for m in MODES},
        'proposals':{m:arms[m]['total_proposals'] for m in MODES},
        'responses':{m:arms[m]['total_positive_responses'] for m in MODES},
        'same_tick_attempts_immediate':arms['immediate']['private_same_tick_attempts'],
        'rejections':{m:arms[m]['private_rejections'] for m in MODES}})
    assert len(records)==24
    def summary(a):
     return {'n':len(a),
       'mean_formed':{m:round(float(np.mean([r['formed'][m] for r in a])),6) for m in MODES},
       'mean_active':{m:round(float(np.mean([r['active'][m] for r in a])),6) for m in MODES},
       'mean_proposals':{m:round(float(np.mean([r['proposals'][m] for r in a])),6) for m in MODES},
       'mean_responses':{m:round(float(np.mean([r['responses'][m] for r in a])),6) for m in MODES},
       'same_tick_bias_attempts_immediate':sum(r['same_tick_attempts_immediate'] for r in a),
       'paired_immediate_minus_lagged_formed':[r['formed']['immediate']-r['formed']['next_tick'] for r in a],
       'paired_immediate_minus_lagged_active':[r['active']['immediate']-r['active']['next_tick'] for r in a],
       'paired_immediate_minus_silent_formed':[r['formed']['immediate']-r['formed']['silent'] for r in a]}
    primary=[r for r in records if r['context']=='mixed_random']
    # Manipulation gate ensures reject update can actually affect later within-tick opportunities.
    assert sum(r['same_tick_attempts_immediate'] for r in primary)>0
    return {'cycle':'N90','design':'private_feedback_timing_frozen',
      'synthetic_only':True,'n_instrumented_runs':72,'n_sham_original_runs':24,
      'n_sham_no_private_runs':24,'n_runs_total':120,'sham_checks_pass':48,
      'original_sha256':ORIGINAL_SHA,'primary':summary(primary),
      'sensitivity':{context:summary([r for r in records if r['context']==context]) for context in CONTEXTS},
      'full_records':records,
      'limits':'Uses original synthetic 144-agent ESBM and six reused seeds, four policy contexts; lagged update affects only subsequent tick, not a modeled real-time attention process; no independent human evidence or original causal sociology.'}

if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('--source',required=True)
    a.add_argument('--out',required=True)
    z=a.parse_args()
    data=execute(z.source)
    Path(z.out).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({k:v for k,v in data.items() if k not in ('full_records','sensitivity')},indent=2))
